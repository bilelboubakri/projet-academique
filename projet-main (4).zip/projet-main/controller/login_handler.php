<?php
header('Content-Type: application/json');

include("../config/database.php");
include("../controller/traitement.php");

 $data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['username'], $data['password'])) {
    echo json_encode(["success" => false, "message" => "Missing credentials"]);
    exit;
}

 $result = LoginUser($cnx, $data['username'], $data['password']);

if ($result['success']) {
    session_start();
    $_SESSION['user_id'] = $result['user']->id;
    $_SESSION['logged_in'] = true;
    
    
    $userData = [
        'id' => $result['user']->id,
        'username' => $result['user']->nom,
        'email' => $result['user']->email,
        'points' => $result['user']->points,
        'level' => $result['user']->level,
        'xp' => $result['user']->xp,
        'total_xp' => $result['user']->total_xp,
        'games_played' => $result['user']->games_played,
        'wins' => $result['user']->wins,
        'losses' => $result['user']->losses,
        'biggest_win' => $result['user']->biggest_win,
        'daily_streak' => $result['user']->daily_streak,
        'last_daily_claim' => $result['user']->last_daily_claim
    ];
    
    echo json_encode([
        "success" => true,
        "message" => "Login successful",
        "user" => $userData
    ]);
} else {
    echo json_encode($result);
}
?>