<?php
header('Content-Type: application/json');
error_reporting(0);

require_once __DIR__ . '/../config/database.php';

 $conn = $GLOBALS['conn'] ?? $GLOBALS['cnx'] ?? $GLOBALS['pdo'] ?? null;

if (!$conn || !($conn instanceof PDO)) {
    echo json_encode(["success" => false, "message" => "No PDO connection"]);
    exit;
}

 $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

try {
    $input = json_decode(file_get_contents("php://input"), true);
    
    $id = (int) ($input["id"] ?? 0);
    $username = $input["username"] ?? "";
    $points = (int) ($input["points"] ?? 0);
    $level = (int) ($input["level"] ?? 1);
    $status = $input["status"] ?? "active";
    $email = $input["email"] ?? "";
    
    if (!$id || !$username) {
        echo json_encode(["success" => false, "message" => "Missing required fields"]);
        exit;
    }
    
   
    $sql = "UPDATE users SET username = :username, points = :points, level = :level, status = :status";
    if ($email) {
        $sql .= ", email = :email";
    }
    $sql .= " WHERE id = :id";
    
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(":username", $username);
    $stmt->bindParam(":points", $points, PDO::PARAM_INT);
    $stmt->bindParam(":level", $level, PDO::PARAM_INT);
    $stmt->bindParam(":status", $status);
    $stmt->bindParam(":id", $id, PDO::PARAM_INT);
    
    if ($email) {
        $stmt->bindParam(":email", $email);
    }
    
    $stmt->execute();
    
    echo json_encode(["success" => true, "message" => "User updated"]);
    
} catch (PDOException $e) {
    echo json_encode(["success" => false, "message" => $e->getMessage()]);
}