<?php


session_start();


if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('location: ../view/user_list.php');
    exit();
}


if (!isset($_POST['idu']) || empty($_POST['idu'])) {
    header('location: ../view/user_list.php?modif=error');
    exit();
}

if (!isset($_POST['user_name']) || empty($_POST['user_name'])) {
    header('location: ../view/user_list.php?modif=error');
    exit();
}

if (!isset($_POST['email']) || empty($_POST['email'])) {
    header('location: ../view/user_list.php?modif=error');
    exit();
}

try {
    include("../config/database.php");
    
    
    $id = filter_var($_POST['idu'], FILTER_VALIDATE_INT);
    $username = htmlspecialchars(trim($_POST['user_name']));
    $email = filter_var(trim($_POST['email']), FILTER_VALIDATE_EMAIL);
    $newPassword = trim($_POST['password'] ?? '');
    
   
    if ($id === false) {
        header('location: ../view/user_list.php?modif=error');
        exit();
    }
    
    if ($email === false) {
        header('location: ../view/user_list.php?modif=error');
        exit();
    }
    
    
    $reqOld = "SELECT password FROM users WHERE id = :id";
    $stmtOld = $cnx->prepare($reqOld);
    $stmtOld->execute(['id' => $id]);
    $oldData = $stmtOld->fetch(PDO::FETCH_ASSOC);
    
    if (!$oldData) {
        
        header('location: ../view/user_list.php?modif=error');
        exit();
    }
    
    
    if (!empty($newPassword)) {

        $password = password_hash($newPassword, PASSWORD_DEFAULT);
    } else {
        
        $password = $oldData['password'];
    }
    
    
    $requete = "UPDATE users 
                SET nom = :nom, 
                    email = :email, 
                    password = :password 
                WHERE id = :id";
    
    $stmt = $cnx->prepare($requete);
    $resultat = $stmt->execute([
        'nom' => $username,
        'email' => $email,
        'password' => $password,
        'id' => $id
    ]);
    
    if ($resultat) {
        
        header('location: ../view/user_list.php?modif=ok');
        exit();
    } else {
        
        header('location: ../view/user_list.php?modif=error');
        exit();
    }
    
} catch (PDOException $e) {
    
    error_log("Update user error: " . $e->getMessage());
    header('location: ../view/user_list.php?modif=error');
    exit();
}
?>