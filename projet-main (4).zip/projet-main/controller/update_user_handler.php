<?php
header('Content-Type: application/json');
error_reporting(0);

include(__DIR__ . "/../config/database.php");


 $data = json_decode(file_get_contents('php://input'), true);


 $userId = (int) ($data['id'] ?? 0);

if (!$userId) {
    echo json_encode(["success" => false, "message" => "Missing user id"]);
    exit;
}

try {
    $req = "UPDATE users SET 
            points = :points,
            level = :level,
            xp = :xp,
            total_xp = :total_xp,
            games_played = :games_played,
            wins = :wins,
            losses = :losses,
            biggest_win = :biggest_win,
            daily_streak = :daily_streak,
            last_daily_claim = :last_daily_claim
            WHERE id = :id";
    
    $stmt = $cnx->prepare($req);
    
    $res = $stmt->execute([
        'points' => $data['points'] ?? 0,
        'level' => $data['level'] ?? 1,
        'xp' => $data['xp'] ?? 0,
        'total_xp' => $data['total_xp'] ?? 0,
        'games_played' => $data['games_played'] ?? 0,
        'wins' => $data['wins'] ?? 0,
        'losses' => $data['losses'] ?? 0,
        'biggest_win' => $data['biggest_win'] ?? 0,
        'daily_streak' => $data['daily_streak'] ?? 0,
        'last_daily_claim' => $data['last_daily_claim'] ?? null,
        'id' => $userId
    ]);
    
    if ($res) {
        echo json_encode(["success" => true, "message" => "User updated"]);
    } else {
        echo json_encode(["success" => false, "message" => "Update failed"]);
    }
    
} catch (Exception $e) {
    echo json_encode(["success" => false, "message" => $e->getMessage()]);
}