<?php
header('Content-Type: application/json');
error_reporting(0);

require_once __DIR__ . '/../config/database.php';

 $conn = $GLOBALS['conn'] ?? $GLOBALS['cnx'] ?? $GLOBALS['pdo'] ?? null;

if (!$conn || !($conn instanceof PDO)) {
    echo json_encode(["success" => false, "message" => "No PDO connection"]);
    exit;
}

 $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

try {
    $input = json_decode(file_get_contents("php://input"), true);
    $ticketId = (int) ($input["ticket_id"] ?? 0);
    
    if (!$ticketId) {
        echo json_encode(["success" => false, "message" => "Missing ticket_id"]);
        exit;
    }
    
    $stmt = $conn->prepare("DELETE FROM support_tickets WHERE id = :id");
    $stmt->bindParam(":id", $ticketId, PDO::PARAM_INT);
    $stmt->execute();
    
    echo json_encode(["success" => true, "message" => "Ticket deleted"]);
    
} catch (PDOException $e) {
    echo json_encode(["success" => false, "message" => $e->getMessage()]);
}