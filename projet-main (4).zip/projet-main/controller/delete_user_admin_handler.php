<?php
header('Content-Type: application/json');
error_reporting(0);

require_once __DIR__ . '/../config/database.php';

 $conn = $GLOBALS['conn'] ?? $GLOBALS['cnx'] ?? $GLOBALS['pdo'] ?? null;

if (!$conn || !($conn instanceof PDO)) {
    echo json_encode(["success" => false, "message" => "No PDO connection"]);
    exit;
}

 $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

try {
    $input = json_decode(file_get_contents("php://input"), true);
    $userId = (int) ($input["user_id"] ?? 0);
    
    if (!$userId) {
        echo json_encode(["success" => false, "message" => "Missing user_id"]);
        exit;
    }
    
    $conn->exec("DELETE FROM support_tickets WHERE user_id = $userId");
    
    $stmt = $conn->prepare("DELETE FROM users WHERE id = :id");
    $stmt->bindParam(":id", $userId, PDO::PARAM_INT);
    $stmt->execute();
    
    if ($stmt->rowCount() === 0) {
        echo json_encode(["success" => false, "message" => "User not found"]);
        exit;
    }
    
    echo json_encode(["success" => true, "message" => "User deleted"]);
    
} catch (PDOException $e) {
    echo json_encode(["success" => false, "message" => $e->getMessage()]);
}