<?php
header('Content-Type: application/json');
error_reporting(0);

include(__DIR__ . "/../config/database.php");

 $data = json_decode(file_get_contents('php://input'), true);
 $userId = (int) ($data['user_id'] ?? 0);

if (!$userId) {
    echo json_encode(["success" => false, "message" => "Missing user_id"]);
    exit;
}

try {
    $stmt = $cnx->prepare("SELECT id, username, email, points, level, xp, total_xp, games_played, wins, losses, biggest_win, daily_streak, last_daily_claim FROM users WHERE id = :id");
    $stmt->execute(['id' => $userId]);
    
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user) {
        echo json_encode(["success" => false, "message" => "User not found"]);
        exit;
    }
    
    echo json_encode([
        "success" => true,
        "user" => [
            "id" => (int) $user["id"],
            "username" => $user["username"],
            "email" => $user["email"] ?? "",
            "points" => (int) $user["points"],
            "level" => (int) $user["level"],
            "xp" => (int) ($user["xp"] ?? 0),
            "total_xp" => (int) ($user["total_xp"] ?? 0),
            "games_played" => (int) ($user["games_played"] ?? 0),
            "wins" => (int) ($user["wins"] ?? 0),
            "losses" => (int) ($user["losses"] ?? 0),
            "biggest_win" => (int) ($user["biggest_win"] ?? 0),
            "daily_streak" => (int) ($user["daily_streak"] ?? 0),
            "last_daily_claim" => $user["last_daily_claim"] ?? null
        ]
    ]);
    
} catch (Exception $e) {
    echo json_encode(["success" => false, "message" => $e->getMessage()]);
}