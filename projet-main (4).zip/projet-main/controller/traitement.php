<?php


include("../config/database.php");
include("../model/User.php");



function AddUser($cnx, $data){
    $req_check = "SELECT id FROM users WHERE username = :username OR email = :email";
    $stmt = $cnx->prepare($req_check);
    $stmt->execute([
        'username' => $data['user_name'], 
        'email' => $data['email']
    ]);
    
    if($stmt->fetch()) {
        return ["success" => false, "message" => "Username or Email already exists"];
    }

    $hashed_password = password_hash($data['password'], PASSWORD_DEFAULT);

    $req = "INSERT INTO users(
                username, 
                email, 
                password, 
                points, 
                level, 
                xp, 
                games_played, 
                wins, 
                losses, 
                daily_streak
            ) VALUES(
                :username, 
                :email, 
                :password, 
                1000, 
                1, 
                0, 
                0, 
                0, 
                0, 
                0
            )";  

    $stmt = $cnx->prepare($req);
    
    $result = $stmt->execute([
        'username' => $data['user_name'],
        'email' => $data['email'],
        'password' => $hashed_password
    ]);

    if($result){
        return ["success" => true, "message" => "User added successfully"];
    } else {
        return ["success" => false, "message" => "Insert failed"];
    }
}

function LoginUser($cnx, $username, $password) {
    $req = "SELECT * FROM users WHERE username = :username";
    $stmt = $cnx->prepare($req);
    $stmt->execute(['username' => $username]);
    
    $row = $stmt->fetch();

    if ($row && password_verify($password, $row['password'])) {
        $user = new User($row['username'], $row['email'], $row['password']);
        
        $user->id = $row['id'];
        $user->points = $row['points'];
        $user->level = $row['level'];
        $user->xp = $row['xp'];
        $user->total_xp = $row['total_xp'];
        $user->games_played = $row['games_played'];
        $user->wins = $row['wins'];
        $user->losses = $row['losses'];
        $user->biggest_win = $row['biggest_win'];
        $user->daily_streak = $row['daily_streak'];
        $user->last_daily_claim = $row['last_daily_claim'];
        
        return ["success" => true, "user" => $user];
    } else {
        return ["success" => false, "message" => "Invalid credentials"];
    }
}

function getAllUsers($cnx){
    $req = "SELECT * FROM users ORDER BY points DESC";
    $res = $cnx->query($req);

    $rows = $res->fetchAll();
    $users = [];
    
    foreach($rows as $row){
        $user = new User($row['username'], $row['email'], $row['password']);
        
        $user->id = $row['id'];
        $user->points = $row['points'];
        $user->level = $row['level'];
        $user->wins = $row['wins'];
        $user->losses = $row['losses'];
        
        $users[] = $user;
    }
    
    return $users;
}

function searchUsers($cnx, $name) {
    $req = "SELECT * FROM users WHERE username LIKE :name";
    $stmt = $cnx->prepare($req);
    $stmt->execute(['name' => "%$name%"]);
    
    $rows = $stmt->fetchAll();
    $users = [];
    
    foreach($rows as $row){
        $user = new User($row['username'], $row['email'], $row['password']);
        $user->id = $row['id'];
        $user->points = $row['points'];
        $users[] = $user;
    }
    
    return $users;
}


function getAllUsersForAdmin($conn) {
    $req = "
        SELECT 
            u.id,
            u.username,
            u.email,
            u.points,
            u.level,
            u.xp,
            u.total_xp,
            u.games_played,
            u.wins,
            u.losses,
            u.biggest_win,
            u.daily_streak,
            u.last_daily_claim,
            u.status,
            u.role,
            u.created_at,
            (SELECT COUNT(gh.id) FROM game_history gh WHERE gh.user_id = u.id) as total_games,
            (SELECT COALESCE(SUM(CASE WHEN gh.outcome = 'win' THEN 1 ELSE 0 END), 0) 
             FROM game_history gh WHERE gh.user_id = u.id) as total_wins,
            (SELECT COALESCE(SUM(CASE WHEN gh.outcome = 'win' THEN gh.profit ELSE 0 END), 0) 
             FROM game_history gh WHERE gh.user_id = u.id) as total_profit
        FROM users u
        ORDER BY u.points DESC
    ";
    
    $result = $conn->query($req);
    
    if ($result) {
        $users = [];
        
        while ($row = $result->fetch_assoc()) {
            $user = new User($row['username'], $row['email'], '');
            
            $user->id = (int)$row['id'];
            $user->points = (int)$row['points'];
            $user->level = (int)$row['level'];
            $user->xp = (int)$row['xp'];
            $user->total_xp = (int)$row['total_xp'];
            $user->games_played = (int)($row['games_played'] ?? 0);
            $user->wins = (int)($row['wins'] ?? 0);
            $user->losses = (int)($row['losses'] ?? 0);
            $user->biggest_win = (int)($row['biggest_win'] ?? 0);
            $user->daily_streak = (int)($row['daily_streak'] ?? 0);
            $user->status = $row['status'] ?? 'active';
            $user->role = $row['role'] ?? 'user';
            $user->created_at = $row['created_at'];
            $user->total_games = (int)($row['total_games'] ?? 0);
            $user->total_wins = (int)($row['total_wins'] ?? 0);
            $user->total_profit = (int)($row['total_profit'] ?? 0);
            
            $users[] = $user;
        }
        
        return [
            'success' => true,
            'users' => $users,
            'total' => count($users)
        ];
    } else {
        return [
            'success' => false, 
            'message' => 'Query failed'
        ];
    }
}


function updateUserAdmin($conn, $data) {
    if (!isset($data['id']) || !isset($data['username'])) {
        return ['success' => false, 'message' => 'Missing required fields'];
    }
    
    $checkReq = "SELECT id FROM users WHERE id = :id";
    $checkStmt = $conn->prepare($checkReq);
    $checkStmt->execute(['id' => (int)$data['id']]);
    
    if (!$checkStmt->fetch()) {
        return ['success' => false, 'message' => 'User not found'];
    }
    
    $updates = [];
    $params = [];
    
    if (isset($data['username'])) {
        $updates[] = "username = :username";
        $params['username'] = $data['username'];
    }
    
    if (isset($data['email'])) {
        $updates[] = "email = :email";
        $params['email'] = $data['email'];
    }
    
    if (isset($data['points'])) {
        $updates[] = "points = :points";
        $params['points'] = (int)$data['points'];
    }
    
    if (isset($data['level'])) {
        $updates[] = "level = :level";
        $params['level'] = (int)$data['level'];
    }
    
    if (isset($data['status'])) {
        $updates[] = "status = :status";
        $params['status'] = $data['status'];
    }
    
    if (isset($data['role'])) {
        $updates[] = "role = :role";
        $params['role'] = $data['role'];
    }
    
    $req = "UPDATE users SET " . implode(', ', $updates) . " WHERE id = :id";
    $params['id'] = (int)$data['id'];
    
    $stmt = $conn->prepare($req);
    $result = $stmt->execute($params);
    
    return [
        'success' => $result ? true : false,
        'message' => $result ? "User updated successfully" : 'Update failed',
        'affected_rows' => $result ? $stmt->rowCount() : 0
    ];
}


function deleteUserAdmin($conn, $userId) {
    if (!isset($userId)) {
        return ['success' => false, 'message' => 'User ID required'];
    }
    
    $check = "SELECT id, username FROM users WHERE id = :id";
    $stmt = $conn->prepare($check);
    $stmt->execute(['id' => (int)$userId]);
    $userToDelete = $stmt->fetch();
    
    if (!$userToDelete) {
        return ['success' => false, 'message' => 'User not found'];
    }
    
    $conn->beginTransaction();
    
    try {
        
        $tables = ['game_history', 'transactions', 'support_tickets'];
        
        foreach ($tables as $table) {
            $delReq = "DELETE FROM {$table} WHERE user_id = :user_id";
            $delStmt = $conn->prepare($delReq);
            $delStmt->execute(['user_id' => (int)$userId]);
        }
        
        // Delete user
        $delUserReq = "DELETE FROM users WHERE id = :id";
        $delUserStmt = $conn->prepare($delUserReq);
        $delUserStmt->execute(['id' => (int)$userId]);
        
        $conn->commit();
        
        return [
            'success' => true, 
            'message' => "User '{$userToDelete['username']}' deleted permanently"
        ];
        
    } catch (Exception $e) {
        $conn->rollBack();
        return [
            'success' => false, 
            'message' => 'Delete failed: ' . $e->getMessage()
        ];
    }
}


function getGameStatsForAdmin($conn) {
    // Get games list
    $gamesReq = "SELECT name, emoji, status, entry_fee, type, description FROM games ORDER BY name";
    $gamesResult = $conn->query($gamesReq);
    
    // Summary stats
    $totalUsers = $conn->query("SELECT COUNT(*) as cnt FROM users")->fetch_assoc()['cnt'];
    $todayGames = $conn->query("SELECT COUNT(*) as cnt FROM game_history WHERE DATE(created_at) = CURDATE()")->fetch_assoc()['cnt'];
    $openTickets = $conn->query("SELECT COUNT(*) as cnt FROM support_tickets WHERE status = 'open'")->fetch_assoc()['cnt'];
    $totalPointsLive = $conn->query("SELECT COALESCE(SUM(points), 0) as sum FROM users")->fetch_assoc()['sum'];
    $newToday = $conn->query("SELECT COUNT(*) as cnt FROM users WHERE DATE(created_at) = CURDATE()")->fetch_assoc()['cnt'];
    
    if ($gamesResult) {
        $games = [];
        
        while ($row = $gamesResult->fetch_assoc()) {
            $games[] = [
                'name' => $row['name'],
                'emoji' => $row['emoji'] ?? '🎮',
                'status' => $row['status'] ?? 'active',
                'entryFee' => (int)($row['entry_fee'] ?? 0),
                'type' => $row['type'] ?? 'casino',
                'description' => $row['description'] ?? ''
            ];
        }
        
        // Get top players from VIEW
        $topPlayersQuery = "
            SELECT id, username, points, level, wins, games_played, total_games, total_profit
            FROM v_user_stats
            ORDER BY points DESC
            LIMIT 5
        ";
        $topPlayersResult = $conn->query($topPlayersQuery);
        $topPlayers = [];
        
        while ($row = $topPlayersResult->fetch_assoc()) {
            $topPlayers[] = [
                'id' => (int)$row['id'],
                'username' => $row['username'],
                'points' => (int)$row['points'],
                'level' => (int)$row['level'],
                'wins' => (int)($row['wins']),
                'games' => (int)($row['games_played']),
                'totalGames' => (int)($row['total_games']),
                'profit' => (int)($row['total_profit'])
            ];
        }
        
        return [
            'success' => true,
            'games' => $games,
            'topPlayers' => $topPlayers,
            'summary' => [
                'totalUsers' => (int)$totalUsers,
                'gamesToday' => (int)$todayGames,
                'openTickets' => (int)$openTickets,
                'totalPoints' => (int)$totalPointsLive,
                'newToday' => (int)$newToday
            ]
        ];
    } else {
        return ['success' => false, 'message' => 'Failed to fetch game stats'];
    }
}


function updateGameStatus($conn, $gameId, $status) {
    if (!isset($gameId) || !isset($status)) {
        return ['success' => false, 'message' => 'Game ID and status required'];
    }
    
    $validStatuses = ['active', 'inactive', 'maintenance'];
    if (!in_array($status, $validStatuses)) {
        return ['success' => false, 'message' => 'Invalid status'];
    }
    
    $req = "UPDATE games SET status = :status WHERE name = :name";
    $stmt = $conn->prepare($req);
    $result = $stmt->execute([
        'status' => $status,
        'name' => $gameId  
    ]);
    
    return [
        'success' => $result ? true : false,
        'message' => $result ? "Game status updated to {$status}" : 'Update failed'
    ];
}



function getSupportTickets($conn, $filter = 'all') {
    $whereClause = '';
    
    switch ($filter) {
        case 'open':
            $whereClause = "WHERE st.status = 'open'";
            break;
        case 'resolved':
            $whereClause = "WHERE st.status = 'resolved'";
            break;
        default:
            $whereClause = '';
            break;
    }
    
    $req = "
        SELECT 
            st.id,
            st.user_id,
            u.username,
            u.email,
            st.subject,
            LEFT(st.message, 200) as message_preview,
            st.message as full_message,
            st.status,
            st.priority,
            st.created_at,
            DATE_FORMAT(st.created_at, '%b %d, %Y %h:%i %p') as time_ago,
            st.resolved_at,
            st.resolved_by
        FROM support_tickets st
        JOIN users u ON st.user_id = u.id
        {$whereClause}
        ORDER BY 
            CASE WHEN st.status = 'open' THEN 0 ELSE 1 END,
            st.created_at DESC
        LIMIT 50
    ";
    
    $result = $conn->query($req);
    
    if ($result) {
        $tickets = [];
        
        while ($row = $result->fetch_assoc()) {
            $tickets[] = [
                'id' => (int)$row['id'],
                'userId' => (int)$row['user_id'],
                'user' => $row['username'],
                'email' => $row['email'],
                'subject' => $row['subject'],
                'message' => $row['message_preview'] . (strlen($row['full_message']) > 200 ? '...' : ''),
                'fullMessage' => $row['full_message'],
                'status' => $row['status'],
                'priority' => $row['priority'] ?? 'low',
                'time' => $row['time_ago'],
                'createdAt' => $row['created_at'],
                'resolvedAt' => $row['resolved_at'],
                'resolvedBy' => $row['resolved_by']
            ];
        }
        
        $openCount = $conn->query("SELECT COUNT(*) as cnt FROM support_tickets WHERE status = 'open'")->fetch_assoc()['cnt'];
        
        return [
            'success' => true,
            'tickets' => $tickets,
            'openCount' => (int)$openCount,
            'total' => count($tickets)
        ];
    } else {
        return ['success' => false, 'message' => 'Failed to fetch tickets'];
    }
}

function resolveTicket($conn, $ticketId, $adminId = null) {
    if (!isset($ticketId)) {
        return ['success' => false, 'message' => 'Ticket ID required'];
    }
    
    $checkReq = "SELECT id, status FROM support_tickets WHERE id = :id";
    $checkStmt = $conn->prepare($checkReq);
    $checkStmt->execute(['id' => (int)$ticketId]);
    $ticket = $checkStmt->fetch();
    
    if (!$ticket) {
        return ['success' => false, 'message' => 'Ticket not found'];
    }
    
    if ($ticket['status'] === 'resolved') {
        return ['success' => false, 'message' => 'Ticket already resolved'];
    }
    
    $req = "
        UPDATE support_tickets 
        SET status = 'resolved',
            resolved_at = NOW(),
            resolved_by = :adminId
        WHERE id = :id
    ";
    
    $stmt = $conn->prepare($req);
    $result = $stmt->execute([
        'id' => (int)$ticketId,
        'adminId' => $adminId ?? 1
    ]);
    
    return [
        'success' => $result ? true : false,
        'message' => $result ? 'Ticket resolved successfully' : 'Resolve failed'
    ];
}

function deleteTicket($conn, $ticketId) {
    if (!isset($ticketId)) {
        return ['success' => false, 'message' => 'Ticket ID required'];
    }
    
    $req = "DELETE FROM support_tickets WHERE id = :id";
    $stmt = $conn->prepare($req);
    $result = $stmt->execute(['id' => (int)$ticketId]);
    
    return [
        'success' => $result && $stmt->rowCount() > 0 ? true : false,
        'message' => $result && $stmt->rowCount() > 0 ? 'Ticket deleted' : 'Delete failed or ticket not found'
    ];
}


function requireAdminAuth($sessionData) {
    if (!$sessionData || !isset($sessionData['id'])) {
        return [
            'success' => false, 
            'authenticated' => false,
            'message' => 'Not authenticated'
        ];
    }
    
    return [
        'success' => true,
        'authenticated' => true,
        'user' => $sessionData
    ];
}
?>