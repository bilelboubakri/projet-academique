<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

 $dbPath = __DIR__ . '/../config/database.php';

if (!file_exists($dbPath)) {
    header('Content-Type: application/json');
    echo json_encode(["success" => false, "message" => "Database config missing"]);
    exit;
}

require_once $dbPath;


 $conn = null;
if (isset($GLOBALS['conn']) && $GLOBALS['conn'] instanceof PDO) {
    $conn = $GLOBALS['conn'];
} elseif (isset($GLOBALS['cnx']) && $GLOBALS['cnx'] instanceof PDO) {
    $conn = $GLOBALS['cnx'];
} elseif (isset($GLOBALS['pdo']) && $GLOBALS['pdo'] instanceof PDO) {
    $conn = $GLOBALS['pdo'];
}

if ($conn === null) {
    header('Content-Type: application/json');
    echo json_encode(["success" => false, "message" => "No PDO connection found"]);
    exit;
}


 $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

try {
    $sql = "SELECT id, username, points, level FROM users ORDER BY points DESC LIMIT 50";
    $stmt = $conn->query($sql);
    
    $users = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $users[] = [
            "id" => (int) $row["id"],
            "username" => $row["username"] ?? "Unknown",
            "points" => (int) $row["points"],
            "level" => (int) $row["level"]
        ];
    }
    
    header('Content-Type: application/json');
    echo json_encode([
        "success" => true,
        "users" => $users,
        "count" => count($users)
    ]);
    
} catch (PDOException $e) {
    header('Content-Type: application/json');
    echo json_encode([
        "success" => false,
        "message" => "Query error: " . $e->getMessage()
    ]);
}