<?php
header('Content-Type: application/json');
error_reporting(0);
ob_start();

include(__DIR__ . "/../config/database.php");

 $data = json_decode(file_get_contents('php://input'), true);
 $userId = (int) ($data['user_id'] ?? 0);

if (!$userId) {
    ob_end_clean();
    echo json_encode(["success" => false, "message" => "Missing user_id"]);
    exit;
}

try {
    
    $stmt = $cnx->prepare("
        SELECT game_name, bet_amount, outcome, profit, created_at 
        FROM game_history 
        WHERE user_id = :user_id 
        ORDER BY created_at DESC 
        LIMIT 20
    ");
    $stmt->execute(['user_id' => $userId]);
    
    $sessions = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $date = $row['created_at'];
        $formattedDate = date('M j', strtotime($date));
        $time = date('H:i', strtotime($date));
        
        if ($formattedDate === date('M j')) {
            $formattedDate = "Today " . $time;
        } elseif ($formattedDate === date('M j', strtotime('-1 day'))) {
            $formattedDate = "Yesterday " . $time;
        } else {
            $formattedDate = $formattedDate . " " . $time;
        }
        
        $sessions[] = [
            "game" => $row["game_name"],
            "result" => $row["outcome"],
            "bet" => (int) $row["bet_amount"],
            "payout" => $row["outcome"] === 'win' ? (int) $row["bet_amount"] + (int) $row["profit"] : 0,
            "profit" => (int) $row["profit"],
            "date" => $formattedDate
        ];
    }
    
    
    $statsStmt = $cnx->prepare("
        SELECT 
            COUNT(*) as total_games,
            SUM(CASE WHEN outcome = 'win' THEN 1 ELSE 0 END) as total_wins,
            SUM(CASE WHEN outcome = 'loss' THEN 1 ELSE 0 END) as total_losses,
            SUM(bet_amount) as total_bet,
            SUM(profit) as net_profit,
            AVG(bet_amount) as avg_bet,
            MAX(CASE WHEN outcome = 'win' THEN profit ELSE 0 END) as best_single_profit
        FROM game_history 
        WHERE user_id = :user_id
    ");
    $statsStmt->execute(['user_id' => $userId]);
    $stats = $statsStmt->fetch(PDO::FETCH_ASSOC);
    
    
    $streakStmt = $cnx->prepare("
        SELECT outcome, 
               SUM(CASE WHEN outcome = 'win' THEN 1 ELSE 0 END) as streak
        FROM (
            SELECT outcome,
                   @streak := IF(outcome = 'win', @streak + 1, 0) as streak_check
            FROM game_history
            WHERE user_id = :user_id
            ORDER BY created_at DESC
        ) sub
        GROUP BY outcome
        ORDER BY streak DESC
        LIMIT 1
    ");
    $streakStmt->execute(['user_id' => $userId]);
    $streakRow = $streakStmt->fetch(PDO::FETCH_ASSOC);
    $hotStreak = (int) ($streakRow['streak'] ?? 0);
    
    
    $favStmt = $cnx->prepare("
        SELECT game_name, COUNT(*) as times_played
        FROM game_history 
        WHERE user_id = :user_id 
        GROUP BY game_name 
        ORDER BY times_played DESC 
        LIMIT 1
    ");
    $favStmt->execute(['user_id' => $userId]);
    $favRow = $favStmt->fetch(PDO::FETCH_ASSOC);
    $favoriteGame = $favRow ? $favRow['game_name'] : 'None yet';
    
    
    $emojis = [
        'Motor Flip' => '🏍️',
        'Risk Ladder' => '📈',
        'Target Precision' => '🎯',
        'Blackjack' => '🃏',
        'Snake Battle' => '🐍',
        'Racing Arena' => '🏎️',
        'Reaction Duel' => '⏱️'
    ];
    
    ob_end_clean();
    
    echo json_encode([
        "success" => true,
        "sessions" => $sessions,
        "stats" => [
            "total_games" => (int) ($stats['total_games'] ?? 0),
            "total_wins" => (int) ($stats['total_wins'] ?? 0),
            "total_losses" => (int) ($stats['total_losses'] ?? 0),
            "total_bet" => (int) ($stats['total_bet'] ?? 0),
            "net_profit" => (int) ($stats['net_profit'] ?? 0),
            "avg_bet" => (int) ($stats['avg_bet'] ?? 0),
            "best_single_profit" => (int) ($stats['best_single_profit'] ?? 0),
            "hot_streak" => $hotStreak,
            "favorite_game" => $favoriteGame,
            "favorite_emoji" => $emojis[$favoriteGame] ?? '🎮'
        ]
    ]);
    
} catch (Exception $e) {
    ob_end_clean();
    echo json_encode(["success" => false, "message" => $e->getMessage()]);
}