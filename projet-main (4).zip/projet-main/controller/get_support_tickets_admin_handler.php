<?php
header('Content-Type: application/json');
error_reporting(0);

include(__DIR__ . "/../config/database.php");

try {
    $input = json_decode(file_get_contents("php://input"), true);
    $filter = $input["filter"] ?? "all";
    
    $sql = "SELECT id, user_id, username, email, subject, message, status, priority, created_at FROM support_tickets";
    
    if ($filter === "open") {
        $sql .= " WHERE status = 'open'";
    } elseif ($filter === "resolved") {
        $sql .= " WHERE status = 'resolved'";
    }
    
    $sql .= " ORDER BY created_at DESC LIMIT 50";
    
    $stmt = $cnx->query($sql);
    
    $tickets = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $tickets[] = [
            "id" => (int) $row["id"],
            "user" => $row["username"] ?? "Unknown",
            "email" => $row["email"] ?? "",
            "subject" => $row["subject"] ?? "No subject",
            "message" => $row["message"] ?? "",
            "fullMessage" => $row["message"] ?? "",
            "status" => $row["status"] ?? "open",
            "priority" => $row["priority"] ?? "low",
            "time" => $row["created_at"] ?? "",
            "createdAt" => $row["created_at"] ?? ""
        ];
    }
    
    $openCount = (int) $cnx->query("SELECT COUNT(*) FROM support_tickets WHERE status = 'open'")->fetchColumn();
    
    echo json_encode([
        "success" => true,
        "tickets" => $tickets,
        "openCount" => $openCount
    ]);
    
} catch (Exception $e) {
    echo json_encode(["success" => false, "message" => $e->getMessage()]);
}