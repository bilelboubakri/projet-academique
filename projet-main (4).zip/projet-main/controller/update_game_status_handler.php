<?php
header('Content-Type: application/json');
error_reporting(0);
ob_start();

include(__DIR__ . "/../config/database.php");

 $data = json_decode(file_get_contents('php://input'), true);

 $gameName = trim($data['game_id'] ?? '');
 $newStatus = trim($data['status'] ?? 'active');

if (!$gameName) {
    ob_end_clean();
    echo json_encode(["success" => false, "message" => "Missing game_id"]);
    exit;
}

 $validStatuses = ['active', 'inactive', 'maintenance'];
if (!in_array($newStatus, $validStatuses)) {
    ob_end_clean();
    echo json_encode(["success" => false, "message" => "Invalid status"]);
    exit;
}

try {
    $stmt = $cnx->prepare("UPDATE games SET status = :status WHERE name = :name");
    $res = $stmt->execute([
        'status' => $newStatus,
        'name' => $gameName
    ]);
    
    ob_end_clean();
    
    if ($stmt->rowCount() > 0) {
        echo json_encode(["success" => true, "message" => "$gameName is now $newStatus"]);
    } else {
        echo json_encode(["success" => false, "message" => "Game not found or no change"]);
    }
    
} catch (Exception $e) {
    ob_end_clean();
    echo json_encode(["success" => false, "message" => $e->getMessage()]);
}