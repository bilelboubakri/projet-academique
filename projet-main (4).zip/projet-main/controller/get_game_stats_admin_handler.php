<?php
header('Content-Type: application/json');
error_reporting(0);
ob_start();

include(__DIR__ . "/../config/database.php");

try {
    
    $totalUsers = (int) $cnx->query("SELECT COUNT(*) FROM users")->fetchColumn();
    $totalPoints = (int) $cnx->query("SELECT COALESCE(SUM(points), 0) FROM users")->fetchColumn();
    $newToday = (int) $cnx->query("SELECT COUNT(*) FROM users WHERE DATE(created_at) = CURDATE()")->fetchColumn();
    
    
    $gamesToday = 0;
    try {
        $gamesToday = (int) $cnx->query("SELECT COUNT(*) FROM game_history WHERE DATE(created_at) = CURDATE()")->fetchColumn();
    } catch(Exception $e) {}
    
    
    $totalGamesPlayed = 0;
    try {
        $totalGamesPlayed = (int) $cnx->query("SELECT COUNT(*) FROM game_history")->fetchColumn();
    } catch(Exception $e) {}
    
    
    $openTickets = 0;
    try {
        $openTickets = (int) $cnx->query("SELECT COUNT(*) FROM support_tickets WHERE status = 'open'")->fetchColumn();
    } catch(Exception $e) {}
    
    
    $topPlayers = [];
    $stmt = $cnx->query("SELECT username, points, wins, games_played FROM users ORDER BY points DESC LIMIT 5");
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $topPlayers[] = [
            "username" => $row["username"],
            "points" => (int) $row["points"],
            "wins" => (int) ($row["wins"] ?? 0),
            "games" => (int) ($row["games_played"] ?? 0)
        ];
    }
    
    
    $games = [];
    try {
        $gameStmt = $cnx->query("SELECT * FROM v_game_stats ORDER BY times_played DESC");
        while ($row = $gameStmt->fetch(PDO::FETCH_ASSOC)) {
            $games[] = [
                "name" => $row["game_name"],
                "emoji" => $row["emoji"] ?? '🎮',
                "status" => $row["status"] ?? 'active',
                "entryFee" => (int) ($row["entry_fee"] ?? 0),
                "played" => (int) ($row["times_played"] ?? 0),
                "wins" => (int) ($row["wins"] ?? 0),
                "losses" => (int) ($row["losses"] ?? 0),
                "volume" => (int) ($row["total_volume"] ?? 0),
                "avgProfit" => (float) ($row["avg_profit"] ?? 0)
            ];
        }
    } catch(Exception $e) {
        
        $gameStmt = $cnx->query("SELECT name, emoji, status, entry_fee FROM games ORDER BY name");
        while ($row = $gameStmt->fetch(PDO::FETCH_ASSOC)) {
            $games[] = [
                "name" => $row["name"],
                "emoji" => $row["emoji"] ?? '🎮',
                "status" => $row["status"] ?? 'active',
                "entryFee" => (int) ($row["entry_fee"] ?? 0),
                "played" => 0,
                "wins" => 0,
                "losses" => 0,
                "volume" => 0,
                "avgProfit" => 0
            ];
        }
    }
    
    ob_end_clean();
    
    echo json_encode([
        "success" => true,
        "summary" => [
            "totalUsers" => $totalUsers,
            "totalPoints" => $totalPoints,
            "gamesToday" => $gamesToday,
            "openTickets" => $openTickets,
            "newToday" => $newToday,
            "totalGamesPlayed" => $totalGamesPlayed
        ],
        "games" => $games,
        "topPlayers" => $topPlayers
    ]);
    
} catch (Exception $e) {
    ob_end_clean();
    echo json_encode(["success" => false, "message" => $e->getMessage()]);
}