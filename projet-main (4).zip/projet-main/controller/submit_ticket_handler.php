<?php
header('Content-Type: application/json');
error_reporting(0);
ob_start();

include(__DIR__ . "/../config/database.php");

 $data = json_decode(file_get_contents('php://input'), true);

 $userId = (int) ($data['user_id'] ?? 0);
 $username = trim($data['username'] ?? '');
 $email = trim($data['email'] ?? '');
 $subject = trim($data['subject'] ?? '');
 $message = trim($data['message'] ?? '');

if (!$userId || !$subject || !$message) {
    ob_end_clean();
    echo json_encode(["success" => false, "message" => "Missing required fields"]);
    exit;
}

try {
    $stmt = $cnx->prepare("INSERT INTO support_tickets (user_id, username, email, subject, message, status, priority, created_at) VALUES (:user_id, :username, :email, :subject, :message, 'open', 'low', NOW())");
    
    $res = $stmt->execute([
        'user_id' => $userId,
        'username' => $username,
        'email' => $email,
        'subject' => $subject,
        'message' => $message
    ]);
    
    ob_end_clean();
    
    if ($res) {
        echo json_encode(["success" => true, "message" => "Ticket submitted"]);
    } else {
        echo json_encode(["success" => false, "message" => "Failed to insert"]);
    }
    
} catch (Exception $e) {
    ob_end_clean();
    echo json_encode(["success" => false, "message" => $e->getMessage()]);
}