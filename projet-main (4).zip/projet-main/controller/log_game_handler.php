<?php
header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "DEBUG START\n";

include(__DIR__ . "/../config/database.php");

echo "Database included: " . (isset($cnx) ? "YES" : "NO") . "\n";

 $raw = file_get_contents('php://input');
echo "Raw input: $raw\n";

 $data = json_decode($raw, true);

if (!$data) {
    echo "ERROR: Could not parse JSON\n";
    exit;
}

 $userId = (int) ($data['user_id'] ?? 0);
 $gameName = trim($data['game_name'] ?? 'Unknown');
 $betAmount = (int) ($data['bet_amount'] ?? 0);
 $outcome = ($data['outcome'] === 'win') ? 'win' : 'loss';
 $profit = (int) ($data['profit'] ?? 0);

echo "Parsed: userId=$userId, game=$gameName, bet=$betAmount, outcome=$outcome, profit=$profit\n";

if (!$userId) {
    echo "ERROR: Missing user_id\n";
    exit;
}

try {
    $stmt = $cnx->prepare("INSERT INTO game_history (user_id, game_name, bet_amount, outcome, profit, created_at) VALUES (:user_id, :game_name, :bet_amount, :outcome, :profit, NOW())");
    
    $res = $stmt->execute([
        'user_id' => $userId,
        'game_name' => $gameName,
        'bet_amount' => $betAmount,
        'outcome' => $outcome,
        'profit' => $profit
    ]);
    
    if ($res) {
        $id = $cnx->lastInsertId();
        echo "SUCCESS! Inserted row ID: $id\n";
    } else {
        echo "FAILED! Error: " . json_encode($stmt->errorInfo()) . "\n";
    }
    
} catch (Exception $e) {
    echo "EXCEPTION: " . $e->getMessage() . "\n";
}