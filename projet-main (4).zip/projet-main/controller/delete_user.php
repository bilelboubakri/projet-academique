<?php


session_start();



// Validate ID exists
if (!isset($_GET['idu']) || empty($_GET['idu'])) {
    header('location: ../view/user_list.php?delete=error');
    exit();
}


 $id_user = filter_var($_GET['idu'], FILTER_VALIDATE_INT);

if ($id_user === false) {
    
    header('location: ../view/user_list.php?delete=error');
    exit();
}

try {
    include("../config/database.php");
    
    
    $requete = "DELETE FROM users WHERE id = :id";
    $stmt = $cnx->prepare($requete);
    $resultat = $stmt->execute(['id' => $id_user]);
    
    if ($resultat && $stmt->rowCount() > 0) {
        
        header('location: ../view/user_list.php?delete=ok');
        exit();
    } else {
        
        header('location: ../view/user_list.php?delete=error');
        exit();
    }
    
} catch (PDOException $e) {
   
    error_log("Delete user error: " . $e->getMessage());
    header('location: ../view/user_list.php?delete=error');
    exit();
}
?>