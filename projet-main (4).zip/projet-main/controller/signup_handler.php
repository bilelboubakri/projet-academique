<?php


error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: application/json');


include("../config/database.php");
include("../controller/traitement.php");

try {
    
    $rawData = file_get_contents('php://input');
    $data = json_decode($rawData, true);
    
    
    if (!isset($data['user_name'], $data['email'], $data['password'])) {
        echo json_encode([
            "success" => false, 
            "message" => "Missing required fields"
        ]);
        exit;
    }
    
    
    if (strlen($data['user_name']) < 3) {
        echo json_encode(["success" => false, "message" => "Username must be at least 3 characters"]);
        exit;
    }
    
    
    if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
        echo json_encode(["success" => false, "message" => "Invalid email format"]);
        exit;
    }
    
    
    if (strlen($data['password']) < 6) {
        echo json_encode(["success" => false, "message" => "Password must be at least 6 characters"]);
        exit;
    }
    
    
    $result = AddUser($cnx, $data);
    
    if ($result['success']) {
        
        $req = "SELECT * FROM users WHERE username = :username";
        $stmt = $cnx->prepare($req);
        $stmt->execute(['username' => $data['user_name']]);
        $newUser = $stmt->fetch();
        
        if ($newUser) {
            
            session_start();
            $_SESSION['user_id'] = $newUser['id'];
            $_SESSION['username'] = $newUser['username'];
            $_SESSION['logged_in'] = true;
            
            
            echo json_encode([
                "success" => true,
                "message" => "User added successfully",
                "user" => [
                    "id" => $newUser['id'],
                    "username" => $newUser['username'],
                    "email" => $newUser['email'],
                    "points" => $newUser['points'],
                    "level" => $newUser['level'],
                    "xp" => $newUser['xp'],
                    "total_xp" => $newUser['total_xp'],
                    "games_played" => $newUser['games_played'],
                    "wins" => $newUser['wins'],
                    "losses" => $newUser['losses'],
                    "biggest_win" => $newUser['biggest_win'],
                    "daily_streak" => $newUser['daily_streak']
                ]
            ]);
        } else {
            echo json_encode(["success" => true, "message" => "User created but couldn't retrieve data"]);
        }
    } else {
        echo json_encode($result);
    }
    
} catch (Exception $e) {
    echo json_encode([
        "success" => false, 
        "message" => "Server error: " . $e->getMessage()
    ]);
}
?>