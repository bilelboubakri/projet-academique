<?php
header('Content-Type: application/json');
error_reporting(0);

require_once __DIR__ . '/../config/database.php';

 $conn = $GLOBALS['conn'] ?? $GLOBALS['cnx'] ?? $GLOBALS['pdo'] ?? null;

if (!$conn || !($conn instanceof PDO)) {
    echo json_encode(["success" => false, "message" => "No PDO connection"]);
    exit;
}

 $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

try {
    $sql = "SELECT id, username, email, points, level, games_played, wins, losses, biggest_win, status, created_at FROM users ORDER BY points DESC";
    $stmt = $conn->query($sql);
    
    $users = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $users[] = [
            "id" => (int) $row["id"],
            "username" => $row["username"] ?? "Unknown",
            "email" => $row["email"] ?? "",
            "points" => (int) $row["points"],
            "level" => (int) $row["level"],
            "games_played" => (int) ($row["games_played"] ?? 0),
            "wins" => (int) ($row["wins"] ?? 0),
            "losses" => (int) ($row["losses"] ?? 0),
            "biggest_win" => (int) ($row["biggest_win"] ?? 0),
            "status" => $row["status"] ?? "active",
            "created_at" => $row["created_at"] ?? "N/A"
        ];
    }
    
    echo json_encode([
        "success" => true,
        "users" => $users,
        "count" => count($users)
    ]);
    
} catch (PDOException $e) {
    echo json_encode(["success" => false, "message" => $e->getMessage()]);
}