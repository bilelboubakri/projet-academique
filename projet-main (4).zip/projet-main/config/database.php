<?php


 $db_server = "127.0.0.1";
 $db_username = "root";
 $db_pwd = "";
 $db_name = "projet";

try {
    
    $cnx = new PDO(
        "mysql:host=$db_server;dbname=$db_name;charset=utf8mb4", 
        $db_username, 
        $db_pwd,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::ATTR_STRINGIFY_FETCHES => false
        ]
    );
    
    
    $pdo = $cnx;
    
} catch(PDOException $e) {
    die("❌ Connection failed: " . $e->getMessage());
}
?>