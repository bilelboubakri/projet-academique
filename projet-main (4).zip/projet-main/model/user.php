<?php


class User {

    public $id;
    public $nom;              
    public $username;         
    public $email;
    public $password;
    public $points;
    public $level;
    public $xp;
    public $total_xp;
    public $games_played;
    public $wins;
    public $losses;
    public $biggest_win;
    public $daily_streak;
    public $last_daily_claim;
    

    public $status = 'active';           
    public $role = 'user';              
    public $created_at = null;          
    public $updated_at = null;           
    

    public $total_games = 0;            
    public $total_wins = 0;              
    public $total_profit = 0;            
    public $points_earned = 0;           

    /**
     * Constructor
     * @param string $nom Username (legacy parameter name)
     * @param string $email Email address
     * @param string $password Hashed password
     */
    public function __construct($nom, $email, $password) {
        
        $this->nom = $nom;
        $this->username = $nom;  
        $this->email = $email;
        $this->password = $password;
        
        
        $this->points = 1000;
        $this->level = 1;
        $this->xp = 0;
        $this->total_xp = 0;
        $this->games_played = 0;
        $this->wins = 0;
        $this->losses = 0;
        $this->biggest_win = 0;
        $this->daily_streak = 0;
        $this->last_daily_claim = null;
        
        
        $this->status = 'active';
        $this->role = 'user';
    }
    

    public function getDisplayName() {
        return $this->username ?? $this->nom ?? 'Unknown';
    }
    

    public function toArray() {
        return [
            'id' => $this->id,
            'username' => $this->username,
            'email' => $this->email,
            'points' => $this->points,
            'level' => $this->level,
            'status' => $this->status,
            'role' => $this->role,
            'games_played' => $this->games_played,
            'wins' => $this->wins,
            'losses' => $this->losses,
            'total_games' => $this->total_games,
            'total_wins' => $this->total_wins,
            'total_profit' => $this->total_profit,
            'created_at' => $this->created_at
        ];
    }
    

    public function isAdmin() {
        return $this->role === 'admin';
    }
    

    public function isActive() {
        return $this->status === 'active';
    }
}
?>