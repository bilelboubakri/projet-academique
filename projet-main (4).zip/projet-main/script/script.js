const DAILY_REWARDS = [50, 75, 100, 150, 200, 300, 500];
const LEVEL_EXP_BASE = 100;
const SINGLE_GAMES = [
  { id: 'motorFlip', name: 'Motor Flip', entry: 50, type: 'Skill', icon: '🏍️', desc: 'Flip to win.' },
  { id: 'riskLadder', name: 'Risk Ladder', entry: 150, type: 'Risk', icon: '📈', desc: 'Climb the ladder.' },
  { id: 'targetPrecision', name: 'Target Precision', entry: 100, type: 'Skill', icon: '🎯', desc: 'Hit targets.' }
];
const MULTI_GAMES = [
  { id: 'snakeBattle', name: 'Snake Battle', entry: 300, type: 'Multi', icon: '🐍', desc: 'Last survivor wins.' },
  { id: 'blackjack', name: 'Blackjack', entry: 0, type: 'Casino', icon: '🃏', desc: 'Beat the dealer.' },
  { id: 'racingArena', name: 'Racing Arena', entry: 250, type: 'Multi', icon: '🏎️', desc: 'Fastest wins.' },
  { id: 'reactionDuel', name: 'Reaction Duel', entry: 200, type: '1v1', icon: '⏱️', desc: 'Test reflexes.' }
];

let currentUser = null;
let riskLadderState = { active: false, currentRung: -1, rungs: [] };
let targetGameState = { active: false, score: 0, timeout: null };

const $ = id => document.getElementById(id);
const formatNumber = num => num.toLocaleString();

// ==========================================
// API CONFIGURATION
// ==========================================
const API_BASE = '../controller';

// ==========================================
// TOAST NOTIFICATIONS
// ==========================================
function showToast(message, type = 'success') {
  const container = $('toastContainer');
  if(!container) return;
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `<span>${message}</span>`;
  container.appendChild(toast);
  setTimeout(() => toast.remove(), 3000);
}

// ==========================================
// NAVIGATION HELPERS
// ==========================================
function toggleDropdown() {
  const dd = $('userDropdown');
  if(dd) dd.classList.toggle('active');
}

function toggleMobileMenu() {
  const nav = $('navLinks');
  if(nav) nav.classList.toggle('open');
}

function setActiveNav() {
  const path = window.location.pathname.split("/").pop() || 'index.html';
  document.querySelectorAll('.nav-link').forEach(link => {
    const href = link.getAttribute('href');
    if (href === path) link.classList.add('active');
    else link.classList.remove('active');
  });
}

// ==========================================
// API-BASED USER MANAGEMENT
// ==========================================

async function createUser(username, email, password) {
    try {
        const response = await fetch(`${API_BASE}/signup_handler.php`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ user_name: username, email, password })
        });
        
        const result = await response.json();
        
        if (result.success) {
            return await authUser(username, password);
        }
        
        return result;
    } catch (error) {
        console.error('Registration error:', error);
        return { success: false, message: 'Connection error' };
    }
}

async function authUser(username, password) {
    try {
        const response = await fetch(`${API_BASE}/login_handler.php`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });
        
        const result = await response.json();
        
        if (result.success) {
            sessionStorage.setItem('pp_session', JSON.stringify(result.user));
            return { success: true, user: result.user };
        }
        
        return result;
    } catch (error) {
        console.error('Login error:', error);
        return { success: false, message: 'Connection error' };
    }
}

async function fetchFreshUserData() {
    try {
        const sessionData = sessionStorage.getItem('pp_session');
        if (!sessionData) return null;
        
        const sessionUser = JSON.parse(sessionData);
        
        const response = await fetch(`${API_BASE}/get_user_handler.php`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ user_id: sessionUser.id })
        });
        
        const result = await response.json();
        
        if (result.success && result.user) {
            sessionStorage.setItem('pp_session', JSON.stringify(result.user));
            return result.user;
        }
        
        return sessionUser;
        
    } catch (error) {
        console.error('Fetch user error:', error);
        const sessionData = sessionStorage.getItem('pp_session');
        return sessionData ? JSON.parse(sessionData) : null;
    }
}

async function saveUser() {
    if (!currentUser) return { success: false };
    
    const userDataForDB = {
        id: currentUser.id,
        username: currentUser.username,
        email: currentUser.email,
        points: currentUser.points,
        level: currentUser.level,
        xp: currentUser.xp || 0,
        total_xp: currentUser.total_xp || 0,
        games_played: currentUser.games_played || 0,
        wins: currentUser.wins || 0,
        losses: currentUser.losses || 0,
        biggest_win: currentUser.biggest_win || 0,
        daily_streak: currentUser.daily_streak || 0,
        last_daily_claim: currentUser.last_daily_claim || null
    };
    
    try {
        const response = await fetch(`${API_BASE}/update_user_handler.php`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(userDataForDB)
        });
        
        const result = await response.json();
        
        if (result.success) {
            sessionStorage.setItem('pp_session', JSON.stringify(currentUser));
            console.log('✅ User data saved & session updated:', currentUser.points, 'pts');
        } else {
            console.error('❌ Save failed:', result.message);
        }
        
        return result;
    } catch (error) {
        console.error('❌ Save error:', error);
        return { success: false };
    }
}

function login(user) {
    currentUser = user;
    sessionStorage.setItem('pp_session', JSON.stringify(user));
    window.location.href = 'home.html';
}

function logout() {
    currentUser = null;
    sessionStorage.removeItem('pp_session');
    
    fetch(`${API_BASE}/logout_handler.php`, { method: 'POST' })
        .catch(err => console.log('Logout:', err));
    
    window.location.href = 'index.html';
}

function getCurrentUser() {
    const sessionData = sessionStorage.getItem('pp_session');
    return sessionData ? JSON.parse(sessionData) : null;
}

// ==========================================
// UI UPDATES
// ==========================================
function updateUI() {
  if (!currentUser) return;
  
  console.log('📊 Updating UI for:', currentUser.username, '| Points:', currentUser.points);
  
  if($('navAvatar')) $('navAvatar').textContent = currentUser.username[0].toUpperCase();
  if($('navBalance')) $('navBalance').textContent = formatNumber(currentUser.points);
  if($('navLevelBadge')) $('navLevelBadge').textContent = currentUser.level;
  if($('navMenuLevel')) $('navMenuLevel').textContent = currentUser.level;

  if($('welcomeUsername')) $('welcomeUsername').textContent = currentUser.username;
  if($('dashBalance')) $('dashBalance').textContent = formatNumber(currentUser.points);
  if($('dashLevel')) $('dashLevel').textContent = currentUser.level;
  
  if($('dashWinRate')) {
    const totalGames = currentUser.games_played || 0;
    const wins = currentUser.wins || 0;
    $('dashWinRate').textContent = totalGames ? Math.round((wins/totalGames)*100) + '%' : '0%';
  }
  
  if($('dashBestWin')) $('dashBestWin').textContent = formatNumber(currentUser.biggest_win || 0);
  
  if($('dashExpBar')) {
    const expNeeded = LEVEL_EXP_BASE * currentUser.level;
    const currentXp = currentUser.xp || 0;
    $('dashExpBar').style.width = `${(currentXp / expNeeded) * 100}%`;
  }

  if($('profileUsername')) $('profileUsername').textContent = currentUser.username;
  if($('profileAvatar')) $('profileAvatar').textContent = currentUser.username[0].toUpperCase();
  if($('profileLevel')) $('profileLevel').textContent = currentUser.level;
  if($('profileGames')) $('profileGames').textContent = currentUser.games_played || 0;
  if($('profileWins')) $('profileWins').textContent = currentUser.wins || 0;
  if($('profileLosses')) $('profileLosses').textContent = currentUser.losses || 0;

  renderGameCards();
  renderLeaderboard();
  updateRewardsPage();
}

function updateRewardsPage() {
  const grid = $('dailyRewardGrid');
  if(!grid) return;
  
  const streak = currentUser.daily_streak || 0;
  
  grid.innerHTML = DAILY_REWARDS.map((val, i) => `
    <div class="p-3 rounded-lg text-center transition-all duration-300 ${i < streak ? 'bg-purple-900/30 border border-purple-500' : 'bg-gray-900 border border-transparent'}">
      <div class="text-xs text-gray-400">Day ${i+1}</div>
      <div class="font-bold text-sm">${val}</div>
    </div>
  `).join('');
}

function renderGameCards() {
  if($('quickPlayGames')) $('quickPlayGames').innerHTML = SINGLE_GAMES.slice(0,3).map(g => createGameCard(g)).join('');
  if($('singleGamesGrid')) $('singleGamesGrid').innerHTML = SINGLE_GAMES.map(g => createGameCard(g)).join('');
  if($('multiGamesGrid')) $('multiGamesGrid').innerHTML = MULTI_GAMES.map(g => createGameCard(g)).join('');
}

// ==========================================
// GAME CARD VISUALS
// ==========================================

function getGameVisuals(id) {
  const defaults = {
    bg: '#13151e',
    ac: '#9333ea',
    glow: 'rgba(147, 51, 234, 0.25)',
    badge: 'Play Now',
    bc: '#9333ea',
    bb: 'rgba(147, 51, 233, 0.15)',
    players: Math.floor(Math.random() * 400) + 100,
    tag: ''
  };

  const configs = {
    'blackjack': { 
      bg: '#0a1610', ac: '#30e8a0', glow: 'rgba(48,232,160,.2)', 
      badge: 'Classic', bc: '#30e8a0', bb: 'rgba(48,232,160,.1)', tag: 'hot' 
    },
    'motorFlip': { 
      bg: '#160a0a', ac: '#e04040', glow: 'rgba(224,64,64,.25)', 
      badge: 'High Risk', bc: '#e04040', bb: 'rgba(224,64,64,.12)', tag: 'hot' 
    },
    'riskLadder': { 
      bg: '#0b140d', ac: '#4cda7a', glow: 'rgba(76,218,122,.2)', 
      badge: 'Climb', bc: '#4cda7a', bb: 'rgba(76,218,122,.12)' 
    },
    'targetPrecision': { 
      bg: '#100b1c', ac: '#9b5be9', glow: 'rgba(155,91,233,.25)', 
      badge: 'Skill', bc: '#9b5be9', bb: 'rgba(155,91,233,.15)' 
    },
    'snakeBattle': { 
      bg: '#0f1830', ac: '#5b7be9', glow: 'rgba(91,123,233,.25)', 
      badge: 'Multiplayer', bc: '#5b7be9', bb: 'rgba(91,123,233,.15)', tag: 'new' 
    },
    'racingArena': { 
      bg: '#14100a', ac: '#e8a730', glow: 'rgba(232,167,48,.2)', 
      badge: 'Racing', bc: '#e8a730', bb: 'rgba(232,167,48,.12)' 
    },
    'reactionDuel': { 
      bg: '#1a2e1a', ac: '#3a6a3a', glow: 'rgba(58,106,58,.2)', 
      badge: '1v1', bc: '#3a6a3a', bb: 'rgba(58,106,58,.12)' 
    }
  };

  return { ...defaults, ...configs[id] };
}

function sceneFor(id) {
  switch (id) {
    case "blackjack":
      return `
        <div class="bj-table"></div>
        <div class="bj-felt-ring"></div>
        <div class="bj-chips" style="bottom:8px;left:50%;transform:translateX(-50%);">
          <div class="bj-chip" style="background:#c0392b;"></div>
          <div class="bj-chip" style="background:#2980b9;"></div>
        </div>
        <div class="bj-card-wrap bj-c1" style="top:22px;"><div class="bj-pc red">♥</div></div>
        <div class="bj-card-wrap bj-c2" style="top:18px;"><div class="bj-pc blk">♠</div></div>
        <div class="bj-card-wrap bj-c3" style="top:16px;"><div class="bj-pc red">♦</div></div>
        <div class="bj-card-wrap bj-c4" style="top:18px;"><div class="bj-pc blk">♣</div></div>
        <div class="bj-card-wrap bj-c5" style="top:22px;"><div class="bj-pc red">A</div></div>`;

    case "motorFlip":
      return `
        <div class="crash-bg"></div>
        <div class="crash-grid">
          <svg width="100%" height="100%">
            <defs><pattern id="g" width="14" height="14" patternUnits="userSpaceOnUse"><path d="M14 0L0 0 0 14" fill="none" stroke="#e04040" stroke-width=".5"/></pattern></defs>
            <rect width="100%" height="100%" fill="url(#g)"/>
          </svg>
        </div>
        <div class="crash-rocket-wrap">
          <div class="crash-rocket">
            <div class="rocket-nose"></div><div class="rocket-body"></div>
            <div class="rocket-fin-l"></div><div class="rocket-fin-r"></div>
            <div class="rocket-flame"><div class="flame-inner"></div></div>
          </div>
        </div>
        <div class="crash-multiplier">2.4x</div>`;

    case "targetPrecision":
      return `
        <div class="target-bg"></div>
        <div class="target-ring tr1" style="width:40px;height:40px;top:50%;left:50%;transform:translate(-50%,-50%);"></div>
        <div class="target-ring tr2" style="width:60px;height:60px;top:50%;left:50%;transform:translate(-50%,-50%);"></div>
        <div class="target-ring tr3" style="width:80px;height:80px;top:50%;left:50%;transform:translate(-50%,-50%);"></div>
        <div class="target-dot" style="top:50%;left:50%;transform:translate(-50%,-50%);"></div>`;

    case "racingArena":
      return `
        <div class="race-bg"></div>
        <div class="race-stripe" style="top:30%;animation-delay:0.0s;"></div>
        <div class="race-stripe" style="top:50%;animation-delay:0.2s;"></div>
        <div class="race-stripe" style="top:70%;animation-delay:0.1s;"></div>
        <div class="race-car" style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);font-size:32px;">🏎️</div>`;

    case "reactionDuel":
      return `
        <div class="clock-bg"></div>
        <div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);">
          <div class="clock-face">
            <div class="clock-hand"></div>
          </div>
        </div>`;

    case "riskLadder":
      return `
        <div class="ladder-bg"></div>
        <div class="ladder-bar lb1" style="left:25%;"></div>
        <div class="ladder-bar lb2" style="left:45%;"></div>
        <div class="ladder-bar lb3" style="left:65%;background:linear-gradient(to top, #e04040, #c0392b);"></div>`;
    
    case "snakeBattle":
       return `
        <div class="cb-bg"></div>
        <div class="cb-arena"></div>
        <div class="sword-wrap" style="top:50%;transform:translateY(-50%);">
          <div class="sword sword-l">
            <div class="sword-tip"></div><div class="sword-blade"></div><div class="sword-guard"></div><div class="sword-handle"></div>
          </div>
          <div class="clash-fx">
            <div class="spark" style="transform:rotate(0deg);"></div>
            <div class="spark" style="transform:rotate(90deg);"></div>
            <div class="spark" style="transform:rotate(180deg);"></div>
          </div>
          <div class="sword sword-r">
            <div class="sword-tip"></div><div class="sword-blade"></div><div class="sword-guard"></div><div class="sword-handle"></div>
          </div>
        </div>`;

    default:
      // ✅ FIXED: Removed reference to undefined 'g' variable
      return `<div class="scene-icon-generic">🎮</div>`;
  }
}

function createGameCard(g) {
  const c = getGameVisuals(g.id);
  
  const tagHtml = c.tag === "hot" ? `<div class="tag-hot">🔥 Hot</div>` :
                  c.tag === "new" ? `<div class="tag-new">New</div>` : "";

  let sceneHtml = sceneFor(g.id);
  
  return `
    <div class="card-sr" onclick="openGame('${g.id}')" style="background:${c.bg}; --ac:${c.ac}; --glow:${c.glow};">
      ${tagHtml}
      
      <div class="pip">
        <span class="live-dot"></span>
        ${c.players.toLocaleString()}
      </div>
      
      <div class="scene">${sceneHtml}</div>
      
      <div class="card-overlay"></div>
      
      <div class="play-btn-sr">Play now</div>
      
      <div class="info-sr">
        <div class="name-sr">${g.name}</div>
        <span class="badge-sr" style="color:${c.bc}; background:${c.bb}">${c.badge}</span>
      </div>
    </div>
  `;
}

// ==========================================
// LEADERBOARD (FIXED)
// ==========================================
async function renderLeaderboard() {
  const list = $('leaderboardList');
  if(!list) return;
  
  list.innerHTML = '<div class="text-center py-8 text-gray-500">⏳ Loading leaderboard...</div>';
  
  try {
    console.log('🏆 Fetching leaderboard from database...');
    const response = await fetch(`${API_BASE}/get_leaderboard_handler.php`);
    
    if (!response.ok) {
      throw new Error(`Server returned ${response.status}`);
    }
    
    const result = await response.json();
    console.log('📥 Leaderboard API response:', result);
    
    let dbUsers = [];
    
    if (result.success && result.users && Array.isArray(result.users)) {
      console.log(`✅ Found ${result.users.length} users in database`);
      
      dbUsers = result.users.map(u => ({
        id: u.id,
        username: u.username || u.nom || u.user_name || 'Unknown',
        points: parseInt(u.points) || 0,
        level: parseInt(u.level) || 1
      }));
      
      console.log('📊 Mapped users:', dbUsers.map(u => `${u.username}: ${u.points}`));
      
    } else {
      console.warn('⚠️ API returned no users or error:', result.message);
    }
    
    // Always add current user if logged in and not already in list
    if (currentUser && currentUser.id && !dbUsers.find(u => u.id === currentUser.id)) {
      dbUsers.push({
        id: currentUser.id,
        username: currentUser.username,
        points: currentUser.points,
        level: currentUser.level
      });
      console.log(`➕ Added current user: ${currentUser.username} (${currentUser.points} pts)`);
    }
    
    // Sort by points descending
    const sortedUsers = dbUsers.sort((a, b) => b.points - a.points);
    
    console.log(`🏆 Final leaderboard: ${sortedUsers.length} players`);
    
    if (sortedUsers.length === 0) {
      list.innerHTML = `
        <div class="text-center py-8 text-gray-500">
          <p class="text-lg mb-2">🎮 No players yet</p>
          <p class="text-sm">Be the first to join the leaderboard!</p>
        </div>
      `;
      return;
    }
    
    list.innerHTML = sortedUsers.slice(0, 10).map((p, i) => `
      <div class="flex items-center gap-3 p-2 rounded-lg transition-all ${
        p.id === currentUser?.id 
          ? 'bg-purple-900/30 border border-purple-500 shadow-lg shadow-purple-500/20' 
          : 'hover:bg-gray-800/50'
      }">
        <div class="font-bold text-sm w-5 ${
          i === 0 ? 'text-yellow-400 text-lg' : 
          i === 1 ? 'text-gray-300' : 
          i === 2 ? 'text-orange-400' : 
          'text-gray-500'
        }">
          ${i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `#${i+1}`}
        </div>
        
        <div class="avatar-btn w-7 h-7 text-xs border-0 ${
          p.id === currentUser?.id ? 'bg-purple-600 ring-2 ring-purple-400' : ''
        }">
          <span>${(p.username)[0].toUpperCase()}</span>
        </div>
        
        <div class="flex-1 font-medium text-sm truncate">
          ${p.username}
          ${p.id === currentUser?.id ? '<span class="ml-1 text-xs text-purple-400 font-normal">(You)</span>' : ''}
        </div>
        
        <div class="font-bold text-sm ${
          p.id === currentUser?.id ? 'text-purple-300' : 'text-purple-300/70'
        }">
          ${formatNumber(p.points)}
        </div>
      </div>
    `).join('');
    
    console.log('✅ Leaderboard rendered successfully!');
    
  } catch (error) {
    console.error('❌ Leaderboard error:', error);
    
    // Fallback: Show only current user
    if (currentUser) {
      list.innerHTML = `
        <div class="flex items-center gap-3 p-2 rounded-lg bg-purple-900/20 border border-purple-500">
          <div class="font-bold text-sm w-5 text-yellow-400">🥇</div>
          <div class="avatar-btn w-7 h-7 text-xs border-0 bg-purple-600"><span>${currentUser.username[0].toUpperCase()}</span></div>
          <div class="flex-1 font-medium text-sm truncate">${currentUser.username} <span class="text-xs text-purple-400">(You)</span></div>
          <div class="font-bold text-sm text-purple-300">${formatNumber(currentUser.points)}</div>
        </div>
        <div class="text-center py-4 text-red-400 text-xs">
          ⚠️ Could not load full leaderboard<br>
          <span class="text-gray-500">${error.message}</span>
        </div>
      `;
    } else {
      list.innerHTML = `
        <div class="text-center py-8 text-red-500">
          <p>❌ Failed to load leaderboard</p>
          <p class="text-xs mt-2 text-gray-400">Error: ${error.message}</p>
        </div>
      `;
    }
  }
}
// ==========================================
// GAME HISTORY LOGGER
// ==========================================
async function logGameHistory(gameName, betAmount, outcome, profit) {
  if (!currentUser) return;
  try {
    await fetch(`${API_BASE}/log_game_handler.php`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        user_id: currentUser.id,
        game_name: gameName,
        bet_amount: betAmount,
        outcome: outcome,
        profit: profit
      })
    });
  } catch(e) { /* Silent fail */ }
}
// ==========================================
// GAME LOGIC
// ==========================================
function openGame(id) {
  document.querySelectorAll('.modal-overlay').forEach(m => m.classList.remove('active'));
  const modal = $(id + 'Modal');
  if(modal) modal.classList.add('active');

  if (id === 'riskLadder') { initRiskLadder(); }
  else if (id === 'targetPrecision') { initTargetGame(); }
  else if (id === 'blackjack') { resetBlackjack(); }
}

function closeGame(id) { 
  const modal = $(id + 'Modal');
  if(modal) modal.classList.remove('active'); 
  
  if(id === 'motorFlip') motorState.active = false;
  if(id === 'targetPrecision') { 
    targetGameState.active = false; 
    clearTimeout(targetGameState.timeout); 
  }
}

// ==========================================
// MOTOR FLIP GAME
// ==========================================
const canvas = $('gameCanvas');
const ctx = canvas ? canvas.getContext('2d') : null;

let motorState = {
  active: false,
  bike: { x: 100, y: 100, vx: 6, vy: 0, angle: 0, angularVel: 0, radius: 20 },
  camera: { x: 0 },
  ground: [],
  currentBet: 0,
  targetFlips: 4,
  currentFlips: 0,
  totalRotation: 0,
  inAir: false,
  gameOver: false,
  mapSeed: 1
};

function generateMotorMap(seed) {
  motorState.ground = [];
  let y = 300;
  for (let i = 0; i < 3000; i++) {
    if (i % 400 < 100) y = 300;
    else if (i % 400 < 150) y -= 4;
    else if (i % 400 < 200) y = 100;
    else if (i % 400 < 250) y += 4;
    else {
       y += (Math.random() - 0.5) * 2;
       y = Math.max(100, Math.min(350, y));
    }
    motorState.ground.push(Math.floor(y));
  }
}

async function startMotorGame() {
  const bet = parseInt($('motorBetInput').value) || 100;
  const target = parseInt($('targetFlipsSelect').value) || 4;
  
  if (currentUser.points < bet) {
    showToast('Not enough points!', 'error');
    return;
  }

  currentUser.points -= bet;
  await saveUser(); 
  updateUI();

  motorState = {
    active: true,
    bike: { x: 100, y: 100, vx: 6, vy: 0, angle: 0, angularVel: 0, radius: 20 },
    camera: { x: 0 },
    ground: [],
    currentBet: bet,
    targetFlips: target,
    currentFlips: 0,
    totalRotation: 0,
    inAir: false,
    gameOver: false,
    mapSeed: Math.random()
  };
  
  generateMotorMap(motorState.mapSeed);
  
  $('betControls').classList.add('hidden');
  $('playControls').classList.remove('hidden');
  $('cashoutControls').classList.add('hidden');
  $('hudFlips').innerText = '0';
  $('hudTarget').innerText = target;
  $('hudBet').innerText = bet;

  requestAnimationFrame(motorGameLoop);
}

const mKeys = { left: false, right: false };
document.addEventListener('keydown', (e) => {
  if (e.key === 'ArrowLeft') mKeys.left = true;
  if (e.key === 'ArrowRight') mKeys.right = true;
});
document.addEventListener('keyup', (e) => {
  if (e.key === 'ArrowLeft') mKeys.left = false;
  if (e.key === 'ArrowRight') mKeys.right = false;
});

function motorGameLoop() {
  if (!motorState.active) return;
  updateMotorPhysics();
  drawMotorGame();
  requestAnimationFrame(motorGameLoop);
}

function updateMotorPhysics() {
  let b = motorState.bike;
  b.x += b.vx;
  motorState.camera.x = b.x - 200;

  let groundIndex = Math.floor(b.x / 2);
  let groundY = motorState.ground[groundIndex] || 300;
  
  const GRAVITY = 0.6;
  const ROTATION_SPEED = 0.15;

  if (b.y < groundY - b.radius) {
    b.vy += GRAVITY;
    b.y += b.vy;
    motorState.inAir = true;

    if (mKeys.left) b.angularVel -= ROTATION_SPEED;
    if (mKeys.right) b.angularVel += ROTATION_SPEED;
    b.angularVel *= 0.95;

    b.angle += b.angularVel;
    motorState.totalRotation += Math.abs(b.angularVel);
    
    let newFlips = Math.floor(motorState.totalRotation / (Math.PI * 2));
    if (newFlips !== motorState.currentFlips) {
      motorState.currentFlips = newFlips;
      $('hudFlips').innerText = motorState.currentFlips;
    }
  } else {
    b.y = groundY - b.radius;
    
    if (motorState.inAir) {
      motorState.inAir = false;
      checkMotorLanding();
    }
    
    b.vy = 0;
    b.angularVel *= 0.8; 
    
    if (!mKeys.left && !mKeys.right) {
       let prevY = motorState.ground[groundIndex - 1] || groundY;
       let slope = Math.atan2(groundY - prevY, 2);
       b.angle = lerp_angle(b.angle, slope, 0.2);
    }
  }
}

function lerp_angle(a, b, t) {
  let diff = b - a;
  while (diff < -Math.PI) diff += Math.PI * 2;
  while (diff > Math.PI) diff -= Math.PI * 2;
  return a + diff * t;
}

function checkMotorLanding() {
  let b = motorState.bike;
  let normAngle = ((b.angle % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2);
  let safeLanding = (normAngle < 0.8 || normAngle > 5.5);

  if (!safeLanding) {
    crashMotorGame();
  } else {
    if (motorState.currentFlips >= motorState.targetFlips) {
      pauseMotorGame();
    } else {
      showToast(`Keep going! Need ${motorState.targetFlips} flips.`, 'info');
    }
  }
}

function pauseMotorGame() {
  motorState.active = false;
  $('playControls').classList.add('hidden');
  $('cashoutControls').classList.remove('hidden');
  
  const mult = motorState.currentFlips >= motorState.targetFlips ? 2 : 1; 
  const win = Math.floor(motorState.currentBet * mult);
  $('potentialWin').innerText = win;
  
  ctx.fillStyle = "rgba(0,0,0,0.6)";
  ctx.fillRect(0,0,900,400);
  ctx.fillStyle = "#10b981";
  ctx.font = "30px Orbitron";
  ctx.fillText(`SUCCESS! ${motorState.currentFlips} Flips!`, 300, 180);
}

async function crashMotorGame() {
  motorState.active = false;
  motorState.gameOver = true;
  currentUser.games_played = (currentUser.games_played || 0) + 1;
  currentUser.losses = (currentUser.losses || 0) + 1;
  await saveUser(); 
  updateUI();
  await logGameHistory('Motor Flip', motorState.currentBet, 'loss', -motorState.currentBet);
  showToast('Crashed! You lost your bet.', 'error');

  ctx.fillStyle = "rgba(0,0,0,0.7)";
  ctx.fillRect(0,0,900,400);
  ctx.fillStyle = "#ef4444";
  ctx.font = "40px Orbitron";
  ctx.fillText("CRASHED!", 320, 200);

  setTimeout(() => {
    closeGame('motorFlip');
    $('betControls').classList.remove('hidden');
    $('playControls').classList.add('hidden');
    $('cashoutControls').classList.add('hidden');
  }, 2000);
}

async function cashoutMotor() {
  const win = Math.floor(motorState.currentBet * 2);
  currentUser.points += win;
  currentUser.games_played = (currentUser.games_played || 0) + 1;
  currentUser.wins = (currentUser.wins || 0) + 1;
  
  if (win > (currentUser.biggest_win || 0)) currentUser.biggest_win = win;
  
  await saveUser(); 
  updateUI();
  await logGameHistory('Motor Flip', motorState.currentBet, 'win', win - motorState.currentBet);
  showToast(`Won ${win} points!`, 'success');
  closeGame('motorFlip');
  $('betControls').classList.remove('hidden');
  $('cashoutControls').classList.add('hidden');
}

function continueMotor() {
  motorState.currentBet *= 2; 
  motorState.targetFlips += 2;
  motorState.active = true;
  
  $('hudTarget').innerText = motorState.targetFlips;
  $('hudBet').innerText = motorState.currentBet;
  $('cashoutControls').classList.add('hidden');
  $('playControls').classList.remove('hidden');
  
  motorState.bike.y = 100;
  motorState.bike.vy = 0;
  motorState.bike.angle = 0;
  motorState.totalRotation = 0;
  motorState.currentFlips = 0;
  $('hudFlips').innerText = 0;

  requestAnimationFrame(motorGameLoop);
}

function drawMotorGame() {
  if(!ctx) return;
  
  ctx.fillStyle = "#0f172a";
  ctx.fillRect(0, 0, 900, 400);

  ctx.fillStyle = "#334155";
  ctx.beginPath();
  ctx.moveTo(0, 400);
  
  let startIdx = Math.floor(motorState.camera.x / 2);
  for (let i = 0; i < 500; i++) {
    let idx = startIdx + i;
    let val = motorState.ground[idx] || 300;
    let drawX = i * 2 - (motorState.camera.x % 2);
    ctx.lineTo(drawX, val);
  }
  ctx.lineTo(900, 400);
  ctx.fill();

  ctx.strokeStyle = "#475569";
  ctx.lineWidth = 1;
  ctx.beginPath();
  for(let i=0; i<500; i+=20) {
     let idx = startIdx + i;
     let val = motorState.ground[idx] || 300;
     let drawX = i * 2 - (motorState.camera.x % 2);
     ctx.moveTo(drawX, val);
     ctx.lineTo(drawX, 400);
  }
  ctx.stroke();

  ctx.save();
  let drawX = motorState.bike.x - motorState.camera.x;
  let drawY = motorState.bike.y;
  
  ctx.translate(drawX, drawY);
  ctx.rotate(motorState.bike.angle);

  ctx.fillStyle = "#9333ea";
  ctx.fillRect(-20, -10, 40, 20);
  
  ctx.fillStyle = "#1e293b";
  ctx.strokeStyle = "#fff";
  ctx.lineWidth = 2;
  ctx.beginPath(); ctx.arc(-14, 10, 10, 0, Math.PI*2); ctx.fill(); ctx.stroke();
  ctx.beginPath(); ctx.arc(14, 10, 10, 0, Math.PI*2); ctx.fill(); ctx.stroke();

  ctx.strokeStyle = "#fbbf24";
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(5, -10);
  ctx.lineTo(5, -25);
  ctx.lineTo(0, -35);
  ctx.stroke();

  ctx.restore();
}

// ==========================================
// OTHER GAMES
// ==========================================

function initRiskLadder() { 
  riskLadderState = { active: true, currentRung: -1, rungs: [{ mult: 1.5, rate: 0.85 }, { mult: 2.0, rate: 0.70 }, { mult: 3.0, rate: 0.55 }, { mult: 5.0, rate: 0.35 }, { mult: 10.0, rate: 0.20 }] }; 
  renderLadder(); 
}

function renderLadder() { 
  if(!$('ladderRungs')) return; 
  $('ladderRungs').innerHTML = riskLadderState.rungs.map((r, i) => `
    <div class="p-3 rounded-lg flex justify-between items-center transition-all ${i === riskLadderState.currentRung ? 'bg-green-900/30 border border-green-500' : i < riskLadderState.currentRung ? 'bg-gray-800 opacity-50' : 'bg-gray-900 hover:bg-gray-800'}">
      <div class="font-mono font-bold">x${r.mult}</div>
      <div class="text-xs text-gray-400">${Math.round(r.rate*100)}%</div>
    </div>`).join(''); 
}

async function climbLadder() { 
  if (!riskLadderState.active) return; 
  const next = riskLadderState.currentRung + 1; 
  if (next >= riskLadderState.rungs.length) return; 
  if (riskLadderState.currentRung === -1) { 
    if (currentUser.points < 150) { showToast('Need 150 pts', 'error'); return; } 
    currentUser.points -= 150; 
    await saveUser(); 
    updateUI(); 
  } 
  const rung = riskLadderState.rungs[next]; 
  if (Math.random() < rung.rate) { 
    riskLadderState.currentRung = next; 
    renderLadder(); 
    showToast('Climbed!', 'success'); 
  } else { 
    currentUser.games_played = (currentUser.games_played || 0) + 1;
    currentUser.losses = (currentUser.losses || 0) + 1;
    await saveUser(); 
    updateUI(); 
    // Add this line inside the else block, BEFORE showToast:
    await logGameHistory('Risk Ladder', 150, 'loss', -150);
    showToast('Fell!', 'error'); 
    closeGame('riskLadder'); 
  } 
}

async function ladderCashOut() { 
  if (riskLadderState.currentRung < 0) return; 
  const win = Math.floor(150 * riskLadderState.rungs[riskLadderState.currentRung].mult); 
  currentUser.points += win; 
  currentUser.games_played = (currentUser.games_played || 0) + 1;
  currentUser.wins = (currentUser.wins || 0) + 1;
  
  if (win > (currentUser.biggest_win || 0)) currentUser.biggest_win = win;
  
  await saveUser(); 
  updateUI(); 
  await logGameHistory('Risk Ladder', 150, 'win', win - 150);
  showToast(`Won ${win} pts!`, 'success'); 
  closeGame('riskLadder'); 
}

function initTargetGame() { 
  targetGameState = { active: false, score: 0 }; 
  if($('targetScore')) $('targetScore').textContent = '0'; 
  if($('targetBoard')) $('targetBoard').innerHTML = '<div class="absolute inset-0 flex items-center justify-center text-gray-500">Click Start</div>'; 
  if($('startTargetBtn')) $('startTargetBtn').classList.remove('hidden'); 
}

async function startTargetGame() { 
  if (currentUser.points < 100) { showToast('Need 100 pts', 'error'); return; } 
  currentUser.points -= 100; 
  await saveUser(); 
  updateUI(); 
  targetGameState.active = true; 
  targetGameState.score = 0; 
  if($('startTargetBtn')) $('startTargetBtn').classList.add('hidden'); 
  spawnTarget(); 
}

function spawnTarget() { 
  if (!targetGameState.active) return; 
  const board = $('targetBoard'); 
  if(!board) return; 
  board.innerHTML = ''; 
  const target = document.createElement('div'); 
  target.className = 'absolute w-12 h-12 bg-purple-500 rounded-full cursor-pointer animate-pulse'; 
  target.style.left = Math.random() * (board.offsetWidth - 48) + 'px'; 
  target.style.top = Math.random() * (board.offsetHeight - 48) + 'px'; 
  target.onclick = () => { 
    targetGameState.score += 100; 
    if($('targetScore')) $('targetScore').textContent = targetGameState.score; 
    spawnTarget(); 
  }; 
  board.appendChild(target); 
  clearTimeout(targetGameState.timeout); 
  targetGameState.timeout = setTimeout(() => { 
    if (target.parentNode) { 
      target.remove(); 
      endTargetGame(); 
    } 
  }, 1200); 
}

async function endTargetGame() { 
  targetGameState.active = false; 
  clearTimeout(targetGameState.timeout); 
  let win = Math.floor(targetGameState.score * 0.5); 
  if (win > 0) { 
    currentUser.points += win; 
    currentUser.games_played = (currentUser.games_played || 0) + 1;
    currentUser.wins = (currentUser.wins || 0) + 1;
    // Add BEFORE the showToast inside the if(win > 0) block:
    await logGameHistory('Target Precision', 100, 'win', win - 100);
    showToast(`Won ${win} pts!`, 'success'); 
  } else { 
    currentUser.games_played = (currentUser.games_played || 0) + 1;
    currentUser.losses = (currentUser.losses || 0) + 1;
    await logGameHistory('Target Precision', 100, 'loss', -100);
    showToast('Too slow!', 'error'); 
  } 
  await saveUser(); 
  updateUI(); 
  if($('startTargetBtn')) $('startTargetBtn').classList.remove('hidden'); 
}

async function startMultiplayerGame(type, fee) {
  if (currentUser.points < fee) { showToast(`Need ${fee} pts`, 'error'); return; }
  currentUser.points -= fee; 
  await saveUser(); 
  updateUI(); 
  showToast('Match found...', 'success');
  
  setTimeout(async () => {
    const win = Math.random() > 0.55;
    if (win) { 
      const prize = Math.floor(fee * 3.5); 
      currentUser.points += prize; 
      currentUser.games_played = (currentUser.games_played || 0) + 1;
      currentUser.wins = (currentUser.wins || 0) + 1;
      // Add BEFORE showToast('Victory!'):
      await logGameHistory(type === 'snake' ? 'Snake Battle' : 'Racing Arena', fee, 'win', prize - fee);
      showToast(`Victory! Won ${prize} pts!`, 'success'); 
    } else { 
      currentUser.games_played = (currentUser.games_played || 0) + 1;
      currentUser.losses = (currentUser.losses || 0) + 1;
      await logGameHistory(type === 'snake' ? 'Snake Battle' : 'Racing Arena', fee, 'loss', -fee);
      showToast('Defeated!', 'error'); 
    }
    await saveUser(); 
    updateUI(); 
    closeGame(type === 'snake' ? 'snakeBattle' : 'racingArena');
  }, 2000);
}

async function startReactionGame() {
  if (currentUser.points < 200) { showToast('Need 200 pts', 'error'); return; }
  currentUser.points -= 200; 
  await saveUser(); 
  updateUI();
  
  if($('reactionDisplay')) { 
    $('reactionDisplay').textContent = 'WAIT'; 
    $('reactionDisplay').style.color = '#ef4444'; 
  }
  if($('startReactionBtn')) $('startReactionBtn').classList.add('hidden');
  
  setTimeout(() => {
    if($('reactionDisplay')) { 
      $('reactionDisplay').textContent = 'CLICK!'; 
      $('reactionDisplay').style.color = '#10b981'; 
    }
    const start = Date.now();
    const handler = async () => {
      const time = Date.now() - start; 
      document.removeEventListener('click', handler);
      const botTime = Math.floor(Math.random() * 200 + 180);
      
      if (time < botTime) { 
        const prize = Math.floor(200 * 1.9); 
        currentUser.points += prize; 
        currentUser.games_played = (currentUser.games_played || 0) + 1;
        currentUser.wins = (currentUser.wins || 0) + 1;
        await logGameHistory('Reaction Duel', 200, 'win', prize - 200);
        showToast(`You won! ${time}ms vs ${botTime}ms`, 'success'); 
      } else { 
        currentUser.games_played = (currentUser.games_played || 0) + 1;
        currentUser.losses = (currentUser.losses || 0) + 1;
        await logGameHistory('Reaction Duel', 200, 'loss', -200);
        showToast(`You lost! ${time}ms vs ${botTime}ms`, 'error'); 
      }
      
      await saveUser(); 
      updateUI(); 
      closeGame('reactionDuel'); 
      if($('startReactionBtn')) $('startReactionBtn').classList.remove('hidden');
    };
    
    document.addEventListener('click', handler);
    setTimeout(() => document.removeEventListener('click', handler), 1000);
  }, Math.random() * 2000 + 1000);
}

async function claimDailyReward() {
  const today = new Date().toDateString();
  
  if (currentUser.last_daily_claim === today) { 
    showToast('Already claimed today', 'error'); 
    return; 
  }
  
  const last = currentUser.last_daily_claim ? new Date(currentUser.last_daily_claim) : null; 
  const now = new Date();
  
  if (last && (now - last) < (1000 * 60 * 60 * 48)) { 
    currentUser.daily_streak = Math.min((currentUser.daily_streak || 0) + 1, 7); 
  } else { 
    currentUser.daily_streak = 1; 
  }
  
  const reward = DAILY_REWARDS[(currentUser.daily_streak - 1) % 7]; 
  currentUser.points += reward; 
  currentUser.last_daily_claim = today;
  
  await saveUser(); 
  updateUI(); 
  showToast(`Claimed ${reward} points!`, 'success');
}

// ==========================================
// BLACKJACK GAME
// ==========================================
let bjDeck = [];
let bjPlayerHand = [];
let bjDealerHand = [];
let bjCurrentBet = 0;
let bjGameActive = false;

const suits = ['♠', '♥', '♦', '♣'];
const values = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];

function createBlackjackDeck() {
  bjDeck = [];
  for (let suit of suits) {
    for (let value of values) {
      bjDeck.push({ suit, value });
    }
  }
  for (let i = bjDeck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [bjDeck[i], bjDeck[j]] = [bjDeck[j], bjDeck[i]];
  }
}

function getCardValue(card) {
  if (['J', 'Q', 'K'].includes(card.value)) return 10;
  if (card.value === 'A') return 11;
  return parseInt(card.value);
}

function calculateHand(hand) {
  let score = 0;
  let aces = 0;
  
  hand.forEach(card => {
    score += getCardValue(card);
    if (card.value === 'A') aces++;
  });

  while (score > 21 && aces > 0) {
    score -= 10;
    aces--;
  }
  
  return score;
}

function renderCard(card, hidden = false) {
  if (hidden) {
    return `<div class="game-card game-card-back"></div>`;
  }
  const isRed = ['♥', '♦'].includes(card.suit);
  return `
    <div class="game-card ${isRed ? 'red' : 'black'}">
      <div class="game-card-value">${card.value}${card.suit}</div>
      <div class="game-card-suit">${card.suit}</div>
      <div class="game-card-value" style="transform: rotate(180deg); margin-top:auto;">${card.value}${card.suit}</div>
    </div>
  `;
}

function updateBlackjackUI(showDealerHidden = true) {
  const playerContainer = $('playerCards');
  const dealerContainer = $('dealerCards');
  
  playerContainer.innerHTML = bjPlayerHand.map(c => renderCard(c)).join('');
  
  if (showDealerHidden && bjDealerHand.length > 0) {
    dealerContainer.innerHTML = renderCard(bjDealerHand[0]) + renderCard(bjDealerHand[1], true);
    $('dealerScore').innerText = "?";
  } else {
    dealerContainer.innerHTML = bjDealerHand.map(c => renderCard(c)).join('');
    $('dealerScore').innerText = calculateHand(bjDealerHand);
  }
  
  $('playerScore').innerText = calculateHand(bjPlayerHand);
  $('currentBetDisplay').innerText = bjCurrentBet;
}

function addBet(amount) {
  if (currentUser.points >= amount) {
    bjCurrentBet += amount;
    updateBlackjackUI();
  } else {
    showToast('Not enough points!', 'error');
  }
}

function clearBet() {
  bjCurrentBet = 0;
  updateBlackjackUI();
}

async function dealBlackjack() {
  if (bjCurrentBet === 0) {
    showToast('Place a bet first!', 'error');
    return;
  }
  
  if (currentUser.points < bjCurrentBet) {
    showToast('Not enough points!', 'error');
    return;
  }

  currentUser.points -= bjCurrentBet;
  await saveUser(); 
  updateUI();

  createBlackjackDeck();
  bjPlayerHand = [bjDeck.pop(), bjDeck.pop()];
  bjDealerHand = [bjDeck.pop(), bjDeck.pop()];
  bjGameActive = true;

  $('bj_bettingPhase').classList.add('hidden');
  $('bj_playingPhase').classList.remove('hidden');
  $('bj_resultPhase').classList.add('hidden');
  
  if (calculateHand(bjPlayerHand) === 21) {
    await endBlackjack();
  } else {
    updateBlackjackUI(true);
  }
}

async function bjAction(action) {
  if (!bjGameActive) return;

  if (action === 'hit') {
    bjPlayerHand.push(bjDeck.pop());
    updateBlackjackUI(true);
    
    if (calculateHand(bjPlayerHand) > 21) {
      await endBlackjack();
    }
  } 
  
  else if (action === 'stand') {
    await endBlackjack();
  } 
  
  else if (action === 'double') {
    if (currentUser.points >= bjCurrentBet) {
      currentUser.points -= bjCurrentBet;
      bjCurrentBet *= 2;
      await saveUser(); 
      updateUI();
      
      bjPlayerHand.push(bjDeck.pop());
      updateBlackjackUI(true);
      await endBlackjack();
    } else {
      showToast('Not enough points to double!', 'error');
    }
  }
}

async function endBlackjack() {
  bjGameActive = false;
  
  updateBlackjackUI(false);
  
  while (calculateHand(bjDealerHand) < 17) {
    bjDealerHand.push(bjDeck.pop());
  }
  
  setTimeout(async () => {
    updateBlackjackUI(false);
    
    const playerScore = calculateHand(bjPlayerHand);
    const dealerScore = calculateHand(bjDealerHand);
    
    let resultMessage = "";
    let winAmount = 0;
    
    if (playerScore > 21) {
      resultMessage = "BUST! You Lose.";
      currentUser.losses = (currentUser.losses || 0) + 1;
    } else if (dealerScore > 21) {
      resultMessage = "Dealer Busts! YOU WIN!";
      winAmount = bjCurrentBet * 2;
    } else if (playerScore === 21 && bjPlayerHand.length === 2) {
      resultMessage = "BLACKJACK! YOU WIN!";
      winAmount = Math.floor(bjCurrentBet * 2.5);
    } else if (playerScore > dealerScore) {
      resultMessage = "YOU WIN!";
      winAmount = bjCurrentBet * 2;
    } else if (playerScore < dealerScore) {
      resultMessage = "Dealer Wins.";
      currentUser.losses = (currentUser.losses || 0) + 1;
    } else {
      resultMessage = "PUSH (Tie)";
      winAmount = bjCurrentBet;
    }

    if (winAmount > 0) {
      currentUser.points += Math.floor(winAmount);
      currentUser.wins = (currentUser.wins || 0) + 1;
      if (winAmount > (currentUser.biggest_win || 0)) {
        currentUser.biggest_win = winAmount;
      }
    }
    
    currentUser.games_played = (currentUser.games_played || 0) + 1;
    
    // ✅ Log game to history before saving
    if (winAmount > 0 && resultMessage.includes("PUSH")) {
      // Tie - no profit, no loss (skip logging or log as tie)
      await logGameHistory('Blackjack', bjCurrentBet, 'loss', 0);
    } else if (winAmount > 0) {
      // Win
      await logGameHistory('Blackjack', bjCurrentBet, 'win', winAmount - bjCurrentBet);
    } else {
      // Loss
      await logGameHistory('Blackjack', bjCurrentBet, 'loss', -bjCurrentBet);
    }
    
    // ✅ Save and update UI
    await saveUser();
    updateUI();
    
    $('resultText').innerText = resultMessage;
    $('bj_playingPhase').classList.add('hidden');
    $('bj_resultPhase').classList.remove('hidden');
    
  }, 800);
}

function resetBlackjack() {
  bjCurrentBet = 0;
  bjPlayerHand = [];
  bjDealerHand = [];
  $('playerCards').innerHTML = '';
  $('dealerCards').innerHTML = '';
  $('playerScore').innerText = '0';
  $('dealerScore').innerText = '0';
  $('currentBetDisplay').innerText = '0';
  
  $('bj_bettingPhase').classList.remove('hidden');
  $('bj_playingPhase').classList.add('hidden');
  $('bj_resultPhase').classList.add('hidden');
}

// ==========================================
// INITIALIZATION
// ==========================================
window.onload = async () => {
  setActiveNav();
  
  const path = window.location.pathname.split("/").pop();
  const protectedPages = ['home.html', 'games.html', 'rewards.html', 'support.html', 'profile.html'];

  // Skip admin page - it has its own initialization
  if (path === 'admin.html' || path === 'admin') {
    return;
  }
  
  const sessionUser = getCurrentUser();
  
  if (sessionUser) {
    console.log('🔄 Found session data, fetching fresh from DB...');
    currentUser = await fetchFreshUserData();
    
    if (!currentUser) {
      console.warn('⚠️ Could not fetch fresh data, using session data');
      currentUser = sessionUser;
    }
    
    console.log('✅ Loaded user:', currentUser.username, '| Points:', currentUser.points);
    updateUI();
    
  } else {
    if (protectedPages.includes(path)) {
      window.location.href = 'login.html';
      return;
    }
  }

  // Login Form Handler
  const loginForm = document.getElementById('loginForm');
  if(loginForm) {
    loginForm.onsubmit = async (e) => {
      e.preventDefault(); 
      
      const btn = loginForm.querySelector('button');
      const originalText = btn.textContent;
      btn.textContent = 'Signing in...';
      btn.disabled = true;
      
      const res = await authUser($('loginUsername').value, $('loginPassword').value); 
      
      btn.textContent = originalText;
      btn.disabled = false;
      
      if(res.success) {
        showToast('Welcome back!', 'success');
        setTimeout(() => login(res.user), 500);
      } else {
        showToast(res.message || 'Invalid credentials', 'error');
      }
    };
  }

  // Register Form Handler
  const regForm = document.getElementById('registerForm');
  if(regForm) {
    regForm.onsubmit = async (e) => {
      e.preventDefault(); 
      
      const btn = regForm.querySelector('button');
      const originalText = btn.textContent;
      btn.textContent = 'Creating account...';
      btn.disabled = true;
      
      const res = await createUser(
        $('regUsername').value, 
        $('regEmail').value, 
        $('regPassword').value
      ); 
      
      btn.textContent = originalText;
      btn.disabled = false;
      
      if(res.success) {
        showToast('Account created!', 'success');
        setTimeout(() => login(res.user), 500);
      } else {
        showToast(res.message || 'Registration failed', 'error');
      }
    };
  }
};

document.addEventListener('click', (e) => {
  if($('userDropdown') && !$('userDropdown').contains(e.target)) $('userDropdown').classList.remove('active');
});
