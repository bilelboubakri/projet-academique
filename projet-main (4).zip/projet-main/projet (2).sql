-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : mar. 28 avr. 2026 à 15:59
-- Version du serveur : 10.4.32-MariaDB
-- Version de PHP : 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `projet`
--

-- --------------------------------------------------------

--
-- Structure de la table `games`
--

CREATE TABLE `games` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `emoji` varchar(10) DEFAULT NULL,
  `status` enum('active','inactive','maintenance') DEFAULT 'active',
  `entry_fee` int(11) DEFAULT 0,
  `type` varchar(50) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `games`
--

INSERT INTO `games` (`id`, `name`, `emoji`, `status`, `entry_fee`, `type`, `description`, `created_at`) VALUES
(1, 'Motor Flip', '🏍️', 'active', 50, 'Skill', NULL, '2026-04-26 15:17:07'),
(2, 'Risk Ladder', '📈', 'active', 150, 'Risk', NULL, '2026-04-26 15:17:07'),
(3, 'Target Precision', '🎯', 'active', 100, 'Skill', NULL, '2026-04-26 15:17:07'),
(4, 'Blackjack', '🃏', 'active', 0, 'Casino', NULL, '2026-04-26 15:17:07'),
(5, 'Snake Battle', '🐍', 'active', 300, 'Multi', NULL, '2026-04-26 15:17:07'),
(6, 'Racing Arena', '🏎️', 'active', 250, 'Multi', NULL, '2026-04-26 15:17:07'),
(7, 'Reaction Duel', '⏱️', 'active', 200, '1v1', NULL, '2026-04-26 15:17:07');

-- --------------------------------------------------------

--
-- Structure de la table `game_history`
--

CREATE TABLE `game_history` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `game_name` varchar(50) NOT NULL,
  `bet_amount` int(11) NOT NULL,
  `outcome` enum('win','loss') NOT NULL,
  `profit` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `game_history`
--

INSERT INTO `game_history` (`id`, `user_id`, `game_name`, `bet_amount`, `outcome`, `profit`, `created_at`) VALUES
(1, 6, 'Test Game', 100, 'win', 50, '2026-04-28 13:24:10'),
(2, 6, 'Test Game', 100, 'win', 50, '2026-04-28 13:24:15'),
(3, 6, 'Test Game', 100, 'win', 50, '2026-04-28 13:24:26'),
(4, 6, 'Test Game', 100, 'win', 50, '2026-04-28 13:24:48'),
(5, 6, 'Test Game', 100, 'win', 50, '2026-04-28 13:24:52'),
(6, 6, 'Test Game', 100, 'win', 50, '2026-04-28 13:26:35'),
(7, 6, 'Test Game', 100, 'win', 50, '2026-04-28 13:26:40'),
(8, 6, 'Test Game', 100, 'win', 50, '2026-04-28 13:26:46'),
(9, 6, 'Risk Ladder', 150, 'loss', -150, '2026-04-28 13:27:19'),
(10, 6, 'Test Game', 100, 'win', 50, '2026-04-28 13:27:24'),
(11, 6, 'Target Precision', 100, 'loss', -100, '2026-04-28 13:27:27'),
(12, 6, 'Target Precision', 100, 'loss', -100, '2026-04-28 13:27:39'),
(13, 6, 'Test Game', 100, 'win', 50, '2026-04-28 13:27:52'),
(14, 6, 'Test Game', 100, 'win', 50, '2026-04-28 13:27:57'),
(15, 6, 'Test Game', 100, 'win', 50, '2026-04-28 13:30:14'),
(16, 6, 'Test Game', 100, 'win', 50, '2026-04-28 13:30:59'),
(17, 6, 'Test Game', 100, 'win', 50, '2026-04-28 13:31:22'),
(18, 6, 'Test Game', 100, 'win', 50, '2026-04-28 13:31:35'),
(19, 6, 'Test Game', 100, 'win', 50, '2026-04-28 13:31:43'),
(20, 6, 'Test Game', 100, 'win', 50, '2026-04-28 13:37:37'),
(21, 6, 'Blackjack', 1000, 'win', 1000, '2026-04-28 13:37:50'),
(22, 6, 'Blackjack', 500, 'loss', -500, '2026-04-28 13:38:04'),
(23, 6, 'Blackjack', 1000, 'win', 1000, '2026-04-28 13:38:13'),
(24, 6, 'Blackjack', 1200, 'loss', -1200, '2026-04-28 13:38:21'),
(25, 6, 'Blackjack', 600, 'loss', 0, '2026-04-28 13:38:29'),
(26, 6, 'Blackjack', 1000, 'win', 1000, '2026-04-28 13:38:37'),
(27, 6, 'Test Game', 100, 'win', 50, '2026-04-28 13:39:34'),
(28, 6, 'Test Game', 100, 'win', 50, '2026-04-28 13:40:07'),
(29, 6, 'Test Game', 100, 'win', 50, '2026-04-28 13:49:53'),
(30, 6, 'Blackjack', 200, 'loss', 0, '2026-04-28 13:50:15');

-- --------------------------------------------------------

--
-- Structure de la table `support_tickets`
--

CREATE TABLE `support_tickets` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `status` enum('open','resolved') DEFAULT 'open',
  `priority` enum('low','high') DEFAULT 'low',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `resolved_at` timestamp NULL DEFAULT NULL,
  `resolved_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `support_tickets`
--

INSERT INTO `support_tickets` (`id`, `user_id`, `username`, `email`, `subject`, `message`, `status`, `priority`, `created_at`, `resolved_at`, `resolved_by`) VALUES
(5, 6, 'haroun1', 'haroun1@gmail.com', 'rewards doesn\'t work', 'i can\'t get my rewards', 'open', 'low', '2026-04-17 01:58:28', NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `transactions`
--

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `points` int(11) DEFAULT 1000,
  `level` int(11) DEFAULT 1,
  `xp` int(11) DEFAULT 0,
  `total_xp` int(11) DEFAULT 0,
  `games_played` int(11) DEFAULT 0,
  `wins` int(11) DEFAULT 0,
  `losses` int(11) DEFAULT 0,
  `biggest_win` int(11) DEFAULT 0,
  `daily_streak` int(11) DEFAULT 0,
  `last_daily_claim` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('active','banned','suspended') DEFAULT 'active',
  `role` enum('user','moderator','admin') DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `points`, `level`, `xp`, `total_xp`, `games_played`, `wins`, `losses`, `biggest_win`, `daily_streak`, `last_daily_claim`, `created_at`, `status`, `role`) VALUES
(6, 'haroun1', 'haroun1@gmail.com', '$2y$10$0JXOQbLmZCaNhwqkIEsjG.ya4bzTnXo7T6nQNg4JVJc8x0AO..zam', 6300, 1, 0, 0, 57, 20, 37, 2000, 1, '0000-00-00', '2026-04-13 14:28:49', 'active', 'user'),
(7, 'haroun2', 'haroun2@gmail.com', '$2y$10$qQyeD2TjyTh9T/Olq6hIVuxMUA2Zm5q3LsiYpR.8LQAp4srGUMV.G', 2350, 1, 0, 0, 5, 3, 2, 800, 1, '0000-00-00', '2026-04-14 01:14:26', 'active', 'user');

-- --------------------------------------------------------

--
-- Doublure de structure pour la vue `v_game_stats`
-- (Voir ci-dessous la vue réelle)
--
CREATE TABLE `v_game_stats` (
`game_name` varchar(50)
,`emoji` varchar(10)
,`status` enum('active','inactive','maintenance')
,`entry_fee` int(11)
,`type` varchar(50)
,`times_played` bigint(21)
,`wins` decimal(22,0)
,`losses` decimal(22,0)
,`avg_profit` decimal(14,4)
,`total_volume` decimal(32,0)
,`last_played` timestamp
);

-- --------------------------------------------------------

--
-- Doublure de structure pour la vue `v_user_stats`
-- (Voir ci-dessous la vue réelle)
--
CREATE TABLE `v_user_stats` (
`id` int(11)
,`username` varchar(50)
,`email` varchar(100)
,`points` int(11)
,`level` int(11)
,`xp` int(11)
,`total_xp` int(11)
,`games_played` int(11)
,`wins` int(11)
,`losses` int(11)
,`biggest_win` int(11)
,`daily_streak` int(11)
,`status` enum('active','banned','suspended')
,`created_at` timestamp
,`total_games` bigint(21)
,`total_profit` decimal(32,0)
,`total_wins` decimal(22,0)
);

-- --------------------------------------------------------

--
-- Structure de la vue `v_game_stats`
--
DROP TABLE IF EXISTS `v_game_stats`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_game_stats`  AS SELECT `g`.`name` AS `game_name`, `g`.`emoji` AS `emoji`, `g`.`status` AS `status`, `g`.`entry_fee` AS `entry_fee`, `g`.`type` AS `type`, count(`gh`.`id`) AS `times_played`, sum(case when `gh`.`outcome` = 'win' then 1 else 0 end) AS `wins`, sum(case when `gh`.`outcome` = 'loss' then 1 else 0 end) AS `losses`, coalesce(avg(`gh`.`profit`),0) AS `avg_profit`, coalesce(sum(`gh`.`bet_amount`),0) AS `total_volume`, max(`gh`.`created_at`) AS `last_played` FROM (`games` `g` left join `game_history` `gh` on(`g`.`name` = `gh`.`game_name`)) GROUP BY `g`.`name`, `g`.`emoji`, `g`.`status`, `g`.`entry_fee`, `g`.`type` ORDER BY count(`gh`.`id`) DESC ;

-- --------------------------------------------------------

--
-- Structure de la vue `v_user_stats`
--
DROP TABLE IF EXISTS `v_user_stats`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_user_stats`  AS SELECT `u`.`id` AS `id`, `u`.`username` AS `username`, `u`.`email` AS `email`, `u`.`points` AS `points`, `u`.`level` AS `level`, `u`.`xp` AS `xp`, `u`.`total_xp` AS `total_xp`, `u`.`games_played` AS `games_played`, `u`.`wins` AS `wins`, `u`.`losses` AS `losses`, `u`.`biggest_win` AS `biggest_win`, `u`.`daily_streak` AS `daily_streak`, `u`.`status` AS `status`, `u`.`created_at` AS `created_at`, (select count(`gh`.`id`) from `game_history` `gh` where `gh`.`user_id` = `u`.`id`) AS `total_games`, (select coalesce(sum(case when `gh`.`outcome` = 'win' then `gh`.`profit` else 0 end),0) from `game_history` `gh` where `gh`.`user_id` = `u`.`id`) AS `total_profit`, (select coalesce(sum(case when `gh`.`outcome` = 'win' then 1 else 0 end),0) from `game_history` `gh` where `gh`.`user_id` = `u`.`id`) AS `total_wins` FROM `users` AS `u` ORDER BY `u`.`points` DESC ;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `games`
--
ALTER TABLE `games`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Index pour la table `game_history`
--
ALTER TABLE `game_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Index pour la table `support_tickets`
--
ALTER TABLE `support_tickets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_created` (`created_at`);

--
-- Index pour la table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `idx_status` (`status`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `games`
--
ALTER TABLE `games`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT pour la table `game_history`
--
ALTER TABLE `game_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT pour la table `support_tickets`
--
ALTER TABLE `support_tickets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT pour la table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `game_history`
--
ALTER TABLE `game_history`
  ADD CONSTRAINT `game_history_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
